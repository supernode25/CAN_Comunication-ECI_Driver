var group___ctrl_types =
[
    [ "ECI_CTRL_INFO", "struct_e_c_i___c_t_r_l___i_n_f_o.html", [
      [ "wCtrlClass", "struct_e_c_i___c_t_r_l___i_n_f_o.html#ac7d56652e2f0b4a563df5b56f92aa78e", null ],
      [ "wCtrlState", "struct_e_c_i___c_t_r_l___i_n_f_o.html#aeece3834cd5194a5dca6c6513e6ecdef", null ]
    ] ],
    [ "ECI_CTRL_CAPABILITIES", "struct_e_c_i___c_t_r_l___c_a_p_a_b_i_l_i_t_i_e_s.html", [
      [ "sCanCaps", "struct_e_c_i___c_t_r_l___c_a_p_a_b_i_l_i_t_i_e_s.html#a91407c91ed465d94138c9563ecd6919f", null ],
      [ "sLinCaps", "struct_e_c_i___c_t_r_l___c_a_p_a_b_i_l_i_t_i_e_s.html#a6ea3ff0a8fe4efbfbe0ea4f64396a56b", null ],
      [ "u", "struct_e_c_i___c_t_r_l___c_a_p_a_b_i_l_i_t_i_e_s.html#ab074119c742e8399ee7f88e2646308bf", null ],
      [ "wCtrlClass", "struct_e_c_i___c_t_r_l___c_a_p_a_b_i_l_i_t_i_e_s.html#afc76d47704622afc8f63b8d0e7e2d069", null ]
    ] ],
    [ "ECI_CTRL_STATUS", "struct_e_c_i___c_t_r_l___s_t_a_t_u_s.html", [
      [ "sCanStatus", "struct_e_c_i___c_t_r_l___s_t_a_t_u_s.html#ac97a7e941f6cb1170366de69d374a8d1", null ],
      [ "sLinStatus", "struct_e_c_i___c_t_r_l___s_t_a_t_u_s.html#a436f314f6f21c4c0276e3c514d3364c7", null ],
      [ "u", "struct_e_c_i___c_t_r_l___s_t_a_t_u_s.html#a0a88ddbdbb00aef6d708622fa7a79185", null ],
      [ "wCtrlClass", "struct_e_c_i___c_t_r_l___s_t_a_t_u_s.html#a0a6c19959b28f141ea123044cdef8b09", null ]
    ] ],
    [ "ECI_CTRL_CONFIG", "struct_e_c_i___c_t_r_l___c_o_n_f_i_g.html", [
      [ "sCanConfig", "struct_e_c_i___c_t_r_l___c_o_n_f_i_g.html#a8a774603bc78926a9abadb9a6e119b31", null ],
      [ "sLinConfig", "struct_e_c_i___c_t_r_l___c_o_n_f_i_g.html#a686074eb1c64eadd93bb34c41af8dcd2", null ],
      [ "u", "struct_e_c_i___c_t_r_l___c_o_n_f_i_g.html#afaf1c86c3b0015f6ee54caea54a1a67f", null ],
      [ "wCtrlClass", "struct_e_c_i___c_t_r_l___c_o_n_f_i_g.html#a2de593be36526bfe7dbeefb639f45c87", null ]
    ] ],
    [ "ECI_CTRL_MESSAGE", "struct_e_c_i___c_t_r_l___m_e_s_s_a_g_e.html", [
      [ "sCanMessage", "struct_e_c_i___c_t_r_l___m_e_s_s_a_g_e.html#a1851cf7eab471443da5c204cc81f0c19", null ],
      [ "sLinMessage", "struct_e_c_i___c_t_r_l___m_e_s_s_a_g_e.html#a2afbaf6184fd9bae46d3aa185d1b050b", null ],
      [ "u", "struct_e_c_i___c_t_r_l___m_e_s_s_a_g_e.html#a06b70db1143362bd7541cdb0c826a106", null ],
      [ "wCtrlClass", "struct_e_c_i___c_t_r_l___m_e_s_s_a_g_e.html#ac0356cf132f336ba8a68453a4b3c8f66", null ]
    ] ],
    [ "ECI_CTRL_CMDREQUEST", "struct_e_c_i___c_t_r_l___c_m_d_r_e_q_u_e_s_t.html", [
      [ "sCanCmdRequest", "struct_e_c_i___c_t_r_l___c_m_d_r_e_q_u_e_s_t.html#ad07b793d3ee954f2db6bd9ffa064c25f", null ],
      [ "sLinCmdRequest", "struct_e_c_i___c_t_r_l___c_m_d_r_e_q_u_e_s_t.html#a5108604b040ea485524c871bbd155343", null ],
      [ "u", "struct_e_c_i___c_t_r_l___c_m_d_r_e_q_u_e_s_t.html#a76e43cb377625c9721ae78ce39ec837f", null ],
      [ "wCtrlClass", "struct_e_c_i___c_t_r_l___c_m_d_r_e_q_u_e_s_t.html#a155581e3b85e38071adf0d130d37e9b2", null ]
    ] ],
    [ "ECI_CTRL_CMDRESPONSE", "struct_e_c_i___c_t_r_l___c_m_d_r_e_s_p_o_n_s_e.html", [
      [ "sCanCmdResponse", "struct_e_c_i___c_t_r_l___c_m_d_r_e_s_p_o_n_s_e.html#ab13b05aa5beb151a5f72ef1fd1448deb", null ],
      [ "sLinCmdResponse", "struct_e_c_i___c_t_r_l___c_m_d_r_e_s_p_o_n_s_e.html#a91c2897b602b55d7b4461c37ed060dc1", null ],
      [ "u", "struct_e_c_i___c_t_r_l___c_m_d_r_e_s_p_o_n_s_e.html#a032d2b7611a98ed552c81725ada1b3ad", null ],
      [ "wCtrlClass", "struct_e_c_i___c_t_r_l___c_m_d_r_e_s_p_o_n_s_e.html#aa0b3a011347918360ee2b92a56f7b492", null ]
    ] ],
    [ "ECI_CTRL_FILTER", "struct_e_c_i___c_t_r_l___f_i_l_t_e_r.html", [
      [ "sCanFilter", "struct_e_c_i___c_t_r_l___f_i_l_t_e_r.html#a5d9d1f5482fac1e4699c6d1d3a528215", null ],
      [ "sLinFilter", "struct_e_c_i___c_t_r_l___f_i_l_t_e_r.html#aef394eea5a8fca1d062de387bd9c8a7a", null ],
      [ "u", "struct_e_c_i___c_t_r_l___f_i_l_t_e_r.html#ad663d60211bb50f03256760d5234e372", null ],
      [ "wCtrlClass", "struct_e_c_i___c_t_r_l___f_i_l_t_e_r.html#ae929b6e2690e799feff2315b942ace66", null ],
      [ "wPadding", "struct_e_c_i___c_t_r_l___f_i_l_t_e_r.html#a267026e5a4f5fbe10a88c72fdf651a0d", null ]
    ] ],
    [ "ECI_MAXCTRLCOUNT", "group___ctrl_types.html#gae5059cf63bfc9b7a435936e33f8fc9ee", null ],
    [ "ECI_CTRL_HDL", "group___ctrl_types.html#gad96b23f7e0bac1e2fe40c5bb9a1591a1", null ],
    [ "e_CTRLCLASS", "group___ctrl_types.html#ga01cfecd5789946cb94aed52c87833360", [
      [ "ECI_CTRL_UNDEFINED", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360ac33efa1b1c0ebde03e2d4b91d0513e1d", null ],
      [ "ECI_CTRL_CAN", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360af51a3b15588ee9fa41cc244b60dbf9f3", null ],
      [ "ECI_CTRL_LIN", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360a0fb6fbc7a88551e68cbf551887e69693", null ],
      [ "ECI_CTRL_FLX", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360a91fc30c230a3e403d07774f5bfcee592", null ],
      [ "ECI_CTRL_KLI", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360a932fdc2859441a6ab056a073eec86040", null ]
    ] ],
    [ "e_CTRLSTATES", "group___ctrl_types.html#gafebad904e641817d598bca66348feb6e", [
      [ "ECI_CTRL_UNCONFIGURED", "group___ctrl_types.html#ggafebad904e641817d598bca66348feb6ea6fe631956b99599dfbe485af6e49127b", null ],
      [ "ECI_CTRL_INITIALIZED", "group___ctrl_types.html#ggafebad904e641817d598bca66348feb6eac84f97ca3d5a759dd252f482cadd8165", null ],
      [ "ECI_CTRL_RUNNING", "group___ctrl_types.html#ggafebad904e641817d598bca66348feb6ea49639fc6bbcafe7294715f15f1728889", null ]
    ] ],
    [ "e_SETTINGS_FLAGS", "group___ctrl_types.html#gaa5254faa4f45c65da14da116f0acee8b", [
      [ "ECI_SETTINGS_FLAG_NONE", "group___ctrl_types.html#ggaa5254faa4f45c65da14da116f0acee8ba2f7797ad3f79bade347f8b99001460de", null ],
      [ "ECI_SETTINGS_FLAG_POLLING_MODE", "group___ctrl_types.html#ggaa5254faa4f45c65da14da116f0acee8badf55464a4822b6b4b26b335a2ba392e6", null ],
      [ "ECI_SETTINGS_FLAG_NO_FW_VERIFY", "group___ctrl_types.html#ggaa5254faa4f45c65da14da116f0acee8bac09d79b10e051d61820794aeb31bce12", null ],
      [ "ECI_SETTINGS_FLAG_NO_FW_DOWNLOAD", "group___ctrl_types.html#ggaa5254faa4f45c65da14da116f0acee8ba35f31a045f7eeb60d6a2b035ff2ef5d0", null ]
    ] ],
    [ "e_STOP_FLAGS", "group___ctrl_types.html#ga4f273935d8236de74ee53782d485aeea", [
      [ "ECI_STOP_FLAG_NONE", "group___ctrl_types.html#gga4f273935d8236de74ee53782d485aeeaa4cf31bc925db1cd6adb62659caae31cd", null ],
      [ "ECI_STOP_FLAG_RESET_CTRL", "group___ctrl_types.html#gga4f273935d8236de74ee53782d485aeeaaf09719bd5a4ad01dbba9d0479b7f5f77", null ],
      [ "ECI_STOP_FLAG_CLEAR_TX_FIFO", "group___ctrl_types.html#gga4f273935d8236de74ee53782d485aeeaac85fbce9e4f1e80419687f202674b1e6", null ],
      [ "ECI_STOP_FLAG_CLEAR_RX_FIFO", "group___ctrl_types.html#gga4f273935d8236de74ee53782d485aeeaa7ac87693a4f28d2cad95821b430be753", null ]
    ] ]
];