var searchData=
[
  ['eci_5fctrl_5fhdl',['ECI_CTRL_HDL',['../group___ctrl_types.html#gad96b23f7e0bac1e2fe40c5bb9a1591a1',1,'ECI_hwtype.h']]],
  ['eci_5fhandle',['ECI_HANDLE',['../_os_eci_8h.html#a8c1b4f26f2ef6b28fddecdcb92d23fdc',1,'OsEci.h']]]
];
