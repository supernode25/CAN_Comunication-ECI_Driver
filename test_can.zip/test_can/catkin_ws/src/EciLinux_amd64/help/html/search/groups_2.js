var searchData=
[
  ['hardware_20structures_20and_20types',['Hardware Structures and Types',['../group___hw_types.html',1,'']]]
];
