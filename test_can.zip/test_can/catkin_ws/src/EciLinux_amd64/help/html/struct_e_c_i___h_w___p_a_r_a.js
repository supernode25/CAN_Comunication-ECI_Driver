var struct_e_c_i___h_w___p_a_r_a =
[
    [ "dwFlags", "struct_e_c_i___h_w___p_a_r_a.html#aa46bc95abf75ac1fdd4c67538d68ef6e", null ],
    [ "sIpSettings", "struct_e_c_i___h_w___p_a_r_a.html#a36e7d7ec58982c3f4ef96208cd239aaa", null ],
    [ "sIsaSettings", "struct_e_c_i___h_w___p_a_r_a.html#af3fc2bb904fa02436ab79bcc843ac0cf", null ],
    [ "sPciSettings", "struct_e_c_i___h_w___p_a_r_a.html#af890eb8760f23af3c3efed232b5f1a47", null ],
    [ "sUsbSettings", "struct_e_c_i___h_w___p_a_r_a.html#a46579539311ed3ae56789033d0f2ac72", null ],
    [ "u", "struct_e_c_i___h_w___p_a_r_a.html#ae375f48ecc26cb863355b0fa35ce88fc", null ],
    [ "wHardwareClass", "struct_e_c_i___h_w___p_a_r_a.html#a25b8dbfcdd8db904ff47351efb8519ae", null ]
];