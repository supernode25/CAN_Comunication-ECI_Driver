var struct_e_c_i___l_o_g___e_n_t_r_y =
[
    [ "dwFlags", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a52dba1ea5ffa09a672ebc4ef6d45c83f", null ],
    [ "dwLostCount", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a26150a17eb553dcaf53956ba82b906f1", null ],
    [ "dwSource", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a5e8b1fb06ff8b9602192f9009273b170", null ],
    [ "dwTime", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a47a767fc5fee2ef11d4a35b1ed7d8a82", null ],
    [ "dwVer", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a4eddad98fe7c007746cf744786d66edd", null ],
    [ "szLog", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a8729a7c50eeb136b4be869c8750b6703", null ],
    [ "u", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a0c13dca7b7396d987c97f135301b5efd", null ],
    [ "V0", "struct_e_c_i___l_o_g___e_n_t_r_y.html#accf5d41668e23c0f3d4bca922c29963d", null ]
];