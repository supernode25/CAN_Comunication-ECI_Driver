var NAVTREE =
[
  [ "ECI API Documentation", "index.html", [
    [ "Overview", "index.html#idx_main_overview", null ],
    [ "Trademark Information", "index.html#idx_main_trademark", null ],
    [ "Info", "index.html#idx_main_info", null ],
    [ "ECI API", "api.html", [
      [ "Overview", "api.html#api_overview", null ],
      [ "ECI API Library States", "api.html#api_LibraryStates", null ],
      [ "Allowed Functions Calls in Different Library States", "api.html#api_AllowedFunctions", null ],
      [ "ECI API Thread Safety", "api.html#api_ThreadSafety", null ],
      [ "Interrupt Mode vs. Polling Mode", "api.html#api_InterruptVsPolling", null ],
      [ "Handling ISA/104 CAN Interfaces", "api.html#api_IsaInterfaces", null ],
      [ "Logging Functions", "api.html#api_LoggingFunctions", null ]
    ] ],
    [ "ECI Device Administrator", "device_admin.html", [
      [ "Device Code Maintenance", "device_admin.html#idx_dev_admin_maintenance", null ],
      [ "Device Information", "device_admin.html#idx_dev_admin_info", null ],
      [ "Command Line Arguments", "device_admin.html#idx_dev_admin_cmdline", null ],
      [ "Device Information Example", "device_admin.html#idx_dev_admin_info_example", null ]
    ] ],
    [ "Installation", "installation.html", [
      [ "System Requirements", "installation.html#InstallationSystemRequirements", null ],
      [ "Getting Started (for USB Interfaces)", "installation.html#InstallationGettingStartedUSB", null ],
      [ "Getting Started (for PCI Interfaces)", "installation.html#InstallationGettingStartedPCI", null ],
      [ "Getting Started (for ISA/104 Interfaces)", "installation.html#InstallationGettingStartedISA", null ],
      [ "Preparing the Kernel Build Environment", "installation.html#PreparingKernelBuildEnvironment", null ],
      [ "Compiling and Installing the Kernel Module", "installation.html#InstallationCompilingKernelModule", null ],
      [ "Uninstalling the Kernel Module and libraries", "installation.html#UninstallKernelModule", null ],
      [ "Compiling ECI Demo", "installation.html#InstallationCompilingECIDemo", null ]
    ] ],
    [ "Introduction into CAN", "intro_can.html", [
      [ "Introduction", "intro_can.html#intro_can_intro", null ],
      [ "Controller Area Network Message Transfer According to the Producer-consumer Principle", "intro_can.html#intro_can_msgtransfer", null ],
      [ "Multimaster-capable, Event-oriented Message Transmission of CAN", "intro_can.html#intro_can_multimaster", null ],
      [ "Lossless, Bit-wise Bus Arbitration", "intro_can.html#intro_can_busarbitration", null ],
      [ "Priority-oriented Message Transmission", "intro_can.html#intro_can_priority", null ],
      [ "Bitrate and Bus Length of CAN Systems", "intro_can.html#intro_can_buslen", null ],
      [ "Message Length and Maximum Message Rate", "intro_can.html#intro_can_busrate", null ],
      [ "Efficient Error Detection and Confinement", "intro_can.html#intro_can_errordetect", null ],
      [ "The Format of a CAN Message", "intro_can.html#intro_can_msgformat", null ],
      [ "ECI API CAN Support", "intro_can.html#intro_can_eci_can", null ]
    ] ],
    [ "Introduction into LIN", "intro_lin.html", [
      [ "Introduction", "intro_lin.html#intro_lin_intro", null ],
      [ "Communication Principle", "intro_lin.html#intro_lin_comm_princip", null ],
      [ "LIN Message Format", "intro_lin.html#intro_lin_msg_format", null ],
      [ "ECI API LIN Support", "intro_lin.html#intro_lin_eci_lin", null ]
    ] ],
    [ "Known Problems", "known_problems.html", [
      [ "PC-I 04/PCI and iPCI-I 320/PCI", "known_problems.html#known_problems_plx9050", null ],
      [ "CAN-IB2x0/PCIe (104) (Linux only)", "known_problems.html#known_problems_ib200dma", null ],
      [ "ECI Device Administrator (RTX only)", "known_problems.html#known_problems_device_admin", null ],
      [ "USB-to-CAN compact/USB-to-CAN II", "known_problems.html#known_problems_usb_to_can", null ],
      [ "iPC-I XC16/PCIe (Linux only)", "known_problems.html#known_problems_xc16_pcie", null ],
      [ "RTX64 2013", "known_problems.html#known_problems_rtx64_shared_library", null ],
      [ "USB-to-CAN V2 family (only INtime 5.2)", "known_problems.html#known_problems_intime_5_02_usb", null ]
    ] ],
    [ "License Agreement and Copyright", "license.html", [
      [ "End User License Agreement for IXXAT Software Products Provided Free-of-Charge.", "license.html#license_agreement", null ],
      [ "Copyright", "license.html#license_copyright", null ]
    ] ],
    [ "Useful Links", "links.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_e_c_i002_8h.html",
"_e_c_i113_8h.html",
"_os_eci_8h.html#a849c3badab99b2b0f02b94c06263ab32",
"group___can_types.html#ga8dcd771e911847500a41454be7858d22",
"group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360a91fc30c230a3e403d07774f5bfcee592",
"group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa3bf545ade053af8c95b1ff9ca6ff431d",
"struct_e_c_i___c_t_r_l___s_t_a_t_u_s.html#a0a6c19959b28f141ea123044cdef8b09"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';