var _e_c_i__version_8h =
[
    [ "VER_BRANCH", "_e_c_i__version_8h.html#a2b5e68049c2c850933b5acd8cca7c494", null ],
    [ "VER_BUILD", "_e_c_i__version_8h.html#a7ce3a6824adeecbb4481086e2ba00fb8", null ],
    [ "VER_MAJOR", "_e_c_i__version_8h.html#ae9b0873c1004a01651f733d556db118c", null ],
    [ "VER_MINOR", "_e_c_i__version_8h.html#ad78650efa42849c5f86d372f11f26403", null ]
];