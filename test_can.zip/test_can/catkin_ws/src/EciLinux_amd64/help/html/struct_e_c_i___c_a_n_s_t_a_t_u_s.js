var struct_e_c_i___c_a_n_s_t_a_t_u_s =
[
    [ "bBtReg0", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a5f8e512de607753bbb11511f4a77eabb", null ],
    [ "bBtReg1", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a8d735b2b3bdc24e26e3037075549b4ec", null ],
    [ "bBusLoad", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a40709f779ee2070fe2bac1eadffb32e0", null ],
    [ "bExMode", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a4cb4a665b85948da90624f846923d8f5", null ],
    [ "bOpMode", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#af82ad737a5c1334331ed336a878c4011", null ],
    [ "bReserved", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a6934e12836be64dca3a3a18581d7d0da", null ],
    [ "dwStatus", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#addbc38638a934fccfbc633e34c64c475", null ],
    [ "dwVer", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a4e96480400974912d870a579d27d2073", null ],
    [ "sBtpFdr", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a7ea48a2622a3507c893241ef2f431108", null ],
    [ "sBtpSdr", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#aea95afb8af19a1759719394fad9cf68a", null ],
    [ "u", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#ae1e6ad8ea50353ffaf5962d0132b8218", null ],
    [ "V0", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a3cd0fa967e93722a6d8d8438c92796c4", null ],
    [ "V1", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#a7b65a3f927dcb9112cec0b104970bce8", null ],
    [ "V2", "struct_e_c_i___c_a_n_s_t_a_t_u_s.html#ac1c9c3ffe5b01bf41c26f73f398e10c7", null ]
];