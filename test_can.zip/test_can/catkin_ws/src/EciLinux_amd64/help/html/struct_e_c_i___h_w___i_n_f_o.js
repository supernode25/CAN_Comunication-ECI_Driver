var struct_e_c_i___h_w___i_n_f_o =
[
    [ "abBmVersion", "struct_e_c_i___h_w___i_n_f_o.html#a081e24d4fede6565da41ac400240b873", null ],
    [ "abFwVersion", "struct_e_c_i___h_w___i_n_f_o.html#a9993fcd30efefc76886a8dea777e3f70", null ],
    [ "abHwVersion", "struct_e_c_i___h_w___i_n_f_o.html#ae9926ded48e2ea944fbcd8877de5c299", null ],
    [ "adwApiVersion", "struct_e_c_i___h_w___i_n_f_o.html#a991699e426bb0b6af3f59506d729bfd1", null ],
    [ "dwCtrlCount", "struct_e_c_i___h_w___i_n_f_o.html#a2c1af9b3708ec4b80bc6148dcbe71a77", null ],
    [ "dwDevId", "struct_e_c_i___h_w___i_n_f_o.html#ad7fddc10c3ac7552225de1e191696987", null ],
    [ "dwVer", "struct_e_c_i___h_w___i_n_f_o.html#adf3d33c540f7aa32b52c834e0874623c", null ],
    [ "sCtrlInfo", "struct_e_c_i___h_w___i_n_f_o.html#aca74a2f12e447190c79a73952f3a80ce", null ],
    [ "szFwIdentification", "struct_e_c_i___h_w___i_n_f_o.html#a84fc08e05b94239caf9455413b4b944a", null ],
    [ "szHwBoardType", "struct_e_c_i___h_w___i_n_f_o.html#a6acdf96535aa647e21380512d1b8b79c", null ],
    [ "szHwSerial", "struct_e_c_i___h_w___i_n_f_o.html#a1059bdd654e665d6945446e6ab245bac", null ],
    [ "u", "struct_e_c_i___h_w___i_n_f_o.html#aac7a928818acb961ad7f44c63a5dfac0", null ],
    [ "V0", "struct_e_c_i___h_w___i_n_f_o.html#acfcbb7a991654e7af431496c12a5b650", null ],
    [ "V1", "struct_e_c_i___h_w___i_n_f_o.html#aab87714d85f7e2bd64e298a084931fc4", null ]
];