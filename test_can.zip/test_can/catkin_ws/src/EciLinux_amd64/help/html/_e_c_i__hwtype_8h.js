var _e_c_i__hwtype_8h =
[
    [ "ECI_INVALID_HANDLE", "_e_c_i__hwtype_8h.html#a25e74abef4367c55f1636aebe9f5e9f3", null ],
    [ "ECI_MAXBOARDCOUNT", "group___hw_types.html#gac3bbebbad3466f0230b3199a873a231e", null ],
    [ "ECI_MAXCTRLCOUNT", "group___ctrl_types.html#gae5059cf63bfc9b7a435936e33f8fc9ee", null ],
    [ "ECI_NO_WAIT", "_e_c_i__hwtype_8h.html#a403c1f0c9dbcc9be2d975091eeeb759d", null ],
    [ "ECI_WAIT_FOREVER", "_e_c_i__hwtype_8h.html#a91872362f0cdd50aac024202e4f94c36", null ],
    [ "ECI_CTRL_HDL", "group___ctrl_types.html#gad96b23f7e0bac1e2fe40c5bb9a1591a1", null ],
    [ "e_CTRLCLASS", "group___ctrl_types.html#ga01cfecd5789946cb94aed52c87833360", [
      [ "ECI_CTRL_UNDEFINED", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360ac33efa1b1c0ebde03e2d4b91d0513e1d", null ],
      [ "ECI_CTRL_CAN", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360af51a3b15588ee9fa41cc244b60dbf9f3", null ],
      [ "ECI_CTRL_LIN", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360a0fb6fbc7a88551e68cbf551887e69693", null ],
      [ "ECI_CTRL_FLX", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360a91fc30c230a3e403d07774f5bfcee592", null ],
      [ "ECI_CTRL_KLI", "group___ctrl_types.html#gga01cfecd5789946cb94aed52c87833360a932fdc2859441a6ab056a073eec86040", null ]
    ] ],
    [ "e_CTRLSTATES", "group___ctrl_types.html#gafebad904e641817d598bca66348feb6e", [
      [ "ECI_CTRL_UNCONFIGURED", "group___ctrl_types.html#ggafebad904e641817d598bca66348feb6ea6fe631956b99599dfbe485af6e49127b", null ],
      [ "ECI_CTRL_INITIALIZED", "group___ctrl_types.html#ggafebad904e641817d598bca66348feb6eac84f97ca3d5a759dd252f482cadd8165", null ],
      [ "ECI_CTRL_RUNNING", "group___ctrl_types.html#ggafebad904e641817d598bca66348feb6ea49639fc6bbcafe7294715f15f1728889", null ]
    ] ],
    [ "e_ECI_STRUCT_VERSION", "_e_c_i__hwtype_8h.html#aeed002f9071c05249138ed2bec9e4dab", [
      [ "ECI_STRUCT_VERSION_V0", "_e_c_i__hwtype_8h.html#aeed002f9071c05249138ed2bec9e4daba35536a2bb9efe6c4bb3948eb80912d9c", null ],
      [ "ECI_STRUCT_VERSION_V1", "_e_c_i__hwtype_8h.html#aeed002f9071c05249138ed2bec9e4dabae05560bb3f99e07bd9fd51c61f19e08c", null ],
      [ "ECI_STRUCT_VERSION_V2", "_e_c_i__hwtype_8h.html#aeed002f9071c05249138ed2bec9e4dabab3f9dcbd9f5dd64f6a699f3a38b42404", null ],
      [ "ECI_STRUCT_VERSION_V3", "_e_c_i__hwtype_8h.html#aeed002f9071c05249138ed2bec9e4daba856c707954d1da9a9e256d98bc27a6e2", null ]
    ] ],
    [ "e_HWCLASS", "group___hw_types.html#gab7c972121be0dcecc25fee9fc2ee4974", [
      [ "ECI_HW_UNDEFINED", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974a6885b67fb4d6519517008608806a3e7f", null ],
      [ "ECI_HW_PCI", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974ad545eed42bca602ecd0eccad612a6e90", null ],
      [ "ECI_HW_ISA", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974acb27c77c2c33f6756a22a3b50502ba11", null ],
      [ "ECI_HW_USB", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974a57861716b576ca308fe64ebf02546c00", null ],
      [ "ECI_HW_IP", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974a52cdb0d7511bf361688c80fde0d9b0ec", null ]
    ] ],
    [ "e_LIBSTATES", "group___hw_types.html#ga465a1b9b5e0ea4e85b1f9e707073a4f5", [
      [ "ECI_UNINITIALIZED", "group___hw_types.html#gga465a1b9b5e0ea4e85b1f9e707073a4f5a1bebdf0399db5d8d0510b23880f735c8", null ],
      [ "ECI_INITIALIZED", "group___hw_types.html#gga465a1b9b5e0ea4e85b1f9e707073a4f5ae270ea84190c6a5767c450cc49dba301", null ],
      [ "ECI_CONFIGURED", "group___hw_types.html#gga465a1b9b5e0ea4e85b1f9e707073a4f5acfb076408b6be369048d64d6c84af7b5", null ]
    ] ],
    [ "e_SETTINGS_FLAGS", "group___ctrl_types.html#gaa5254faa4f45c65da14da116f0acee8b", [
      [ "ECI_SETTINGS_FLAG_NONE", "group___ctrl_types.html#ggaa5254faa4f45c65da14da116f0acee8ba2f7797ad3f79bade347f8b99001460de", null ],
      [ "ECI_SETTINGS_FLAG_POLLING_MODE", "group___ctrl_types.html#ggaa5254faa4f45c65da14da116f0acee8badf55464a4822b6b4b26b335a2ba392e6", null ],
      [ "ECI_SETTINGS_FLAG_NO_FW_VERIFY", "group___ctrl_types.html#ggaa5254faa4f45c65da14da116f0acee8bac09d79b10e051d61820794aeb31bce12", null ],
      [ "ECI_SETTINGS_FLAG_NO_FW_DOWNLOAD", "group___ctrl_types.html#ggaa5254faa4f45c65da14da116f0acee8ba35f31a045f7eeb60d6a2b035ff2ef5d0", null ]
    ] ],
    [ "e_STOP_FLAGS", "group___ctrl_types.html#ga4f273935d8236de74ee53782d485aeea", [
      [ "ECI_STOP_FLAG_NONE", "group___ctrl_types.html#gga4f273935d8236de74ee53782d485aeeaa4cf31bc925db1cd6adb62659caae31cd", null ],
      [ "ECI_STOP_FLAG_RESET_CTRL", "group___ctrl_types.html#gga4f273935d8236de74ee53782d485aeeaaf09719bd5a4ad01dbba9d0479b7f5f77", null ],
      [ "ECI_STOP_FLAG_CLEAR_TX_FIFO", "group___ctrl_types.html#gga4f273935d8236de74ee53782d485aeeaac85fbce9e4f1e80419687f202674b1e6", null ],
      [ "ECI_STOP_FLAG_CLEAR_RX_FIFO", "group___ctrl_types.html#gga4f273935d8236de74ee53782d485aeeaa7ac87693a4f28d2cad95821b430be753", null ]
    ] ]
];