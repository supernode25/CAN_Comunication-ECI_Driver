var group___lin_types =
[
    [ "ECI_LININITLINE", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html", [
      [ "bOpMode", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a6d6ba0c51e10683f2b0d1d2330e58847", null ],
      [ "bReserved", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a977d2340e1cb70c3c122a1a105f97f4a", null ],
      [ "dwVer", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#aa7181b9b406cafc0b3c0fe0f05079506", null ],
      [ "u", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a9f4cc2fde56cf9d2a1ebd093deb6eb51", null ],
      [ "V0", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a4ca9cc9820d5cc6175997f43f641d264", null ],
      [ "wBitrate", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a1a24d5443f110fe311595223cdafcb63", null ]
    ] ],
    [ "ECI_LINCAPABILITIES", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html", [
      [ "dwClockFreq", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aa8121fa431924ca34fe3ccb4caa8cb8d", null ],
      [ "dwDtxDivisor", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#ac1565d6a1e12f4eff05fd4c99326521c", null ],
      [ "dwDtxMaxTicks", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aecf4fd05095cf268fa7d4d22039fc845", null ],
      [ "dwFeatures", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a9109141350e885037eab418b6c5f83e5", null ],
      [ "dwNoOfPrioQueues", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#ab195c014e95066ed0af02adfaa35a9de", null ],
      [ "dwTscDivisor", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a9e439b7e7eba6c7096c3d180916d583f", null ],
      [ "dwVer", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a9fdfd5079d9be6e2109f5925aa351f8a", null ],
      [ "u", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a42782f96de905d3716629a8ab9758df0", null ],
      [ "V0", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a6fd9acb4c3fe3cd588f33194844074f3", null ],
      [ "wBusCoupling", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aafabd30daaf601bf70922a47c72befda", null ],
      [ "wLinType", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aa09a90eeda0445dd2078da8fab0d60eb", null ]
    ] ],
    [ "ECI_LINSTATUS", "struct_e_c_i___l_i_n_s_t_a_t_u_s.html", [
      [ "bBusLoad", "struct_e_c_i___l_i_n_s_t_a_t_u_s.html#a1e197677875480a282ed7f63569fdb1d", null ],
      [ "bOpMode", "struct_e_c_i___l_i_n_s_t_a_t_u_s.html#ad2967e38f5af8a52d886211f2b6b7789", null ],
      [ "dwStatus", "struct_e_c_i___l_i_n_s_t_a_t_u_s.html#ad027a8dae9ae4cf931fd498bfcf569a6", null ],
      [ "dwVer", "struct_e_c_i___l_i_n_s_t_a_t_u_s.html#abd380297d2509bc64da2e5b20b8e332f", null ],
      [ "u", "struct_e_c_i___l_i_n_s_t_a_t_u_s.html#afb1d5b9732733f00a6fff5bf34be9d9c", null ],
      [ "V0", "struct_e_c_i___l_i_n_s_t_a_t_u_s.html#a9e3e9fabe40c93e6e929c9f31e6eb138", null ],
      [ "wBitrate", "struct_e_c_i___l_i_n_s_t_a_t_u_s.html#a2fb9ddaf241cf035864fb44a6b987b88", null ]
    ] ],
    [ "ECI_LINMSGINFO", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html", [
      [ "bFlags", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#abc4e5781992abd9c44c8a8cd188799eb", null ],
      [ "bFlags2", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a0fa86bb16ea8508d5e9e9612524366ec", null ],
      [ "Bits", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#ae52a4dd9abd16f521178b359f95cc403", null ],
      [ "bReserved2", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a051d9974559ced3f7f3c808113428a97", null ],
      [ "bType", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#ac5d8ce5335e8de9cca5775ff4142a66a", null ],
      [ "buf", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#ad992827322d48912f86df94a0b4113db", null ],
      [ "Bytes", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#aa8e10da198dec3cd511022d6543df73b", null ],
      [ "dlc", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a943df07fdcbbd98f84d5fcd6a330ee73", null ],
      [ "ecs", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#aad3d874d34aaa3c0eacd1d6e540e35c1", null ],
      [ "ido", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#af79952fc6435450e066eaaef3776b373", null ],
      [ "ovr", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a6fa38dfbf737e517fc0e04c95f1e6e3f", null ],
      [ "res", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a6434aa59fd81f18b4b56b65538e576fc", null ],
      [ "res2", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a2640c2baacc0cc8c81855e78d43e7abc", null ],
      [ "sor", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a4fdd23f72564fcf7240e886a239957f2", null ],
      [ "type", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a5ddc95442826206b852343eecf59c92d", null ]
    ] ],
    [ "ECI_LINMESSAGE", "struct_e_c_i___l_i_n_m_e_s_s_a_g_e.html", [
      [ "abData", "struct_e_c_i___l_i_n_m_e_s_s_a_g_e.html#aff7124dd3749eac3ad780a0d70bca60d", null ],
      [ "dwMsgId", "struct_e_c_i___l_i_n_m_e_s_s_a_g_e.html#a99568f389df86f50403f3bf9d6154765", null ],
      [ "dwTime", "struct_e_c_i___l_i_n_m_e_s_s_a_g_e.html#a20c354701f81ca65d700013930043a7d", null ],
      [ "dwVer", "struct_e_c_i___l_i_n_m_e_s_s_a_g_e.html#a80d91151518ff5552b11a5cb87a1bc42", null ],
      [ "u", "struct_e_c_i___l_i_n_m_e_s_s_a_g_e.html#ad20140f87f1828b3e7b03da763a14eba", null ],
      [ "uMsgInfo", "struct_e_c_i___l_i_n_m_e_s_s_a_g_e.html#a780b10ae4191c3415c36a28778e0b7ef", null ],
      [ "V0", "struct_e_c_i___l_i_n_m_e_s_s_a_g_e.html#ab19dbf22685421dc50f181758606d985", null ]
    ] ],
    [ "ECI_LIN_CMD_REQ_HD", "struct_e_c_i___l_i_n___c_m_d___r_e_q___h_d.html", [
      [ "wCode", "struct_e_c_i___l_i_n___c_m_d___r_e_q___h_d.html#a008bc9ce72509c28a33054519f9df3e3", null ]
    ] ],
    [ "ECI_LIN_CMD_RES_HD", "struct_e_c_i___l_i_n___c_m_d___r_e_s___h_d.html", [
      [ "wResult", "struct_e_c_i___l_i_n___c_m_d___r_e_s___h_d.html#aa339454683f3b4adce3ddd1912564a20", null ]
    ] ],
    [ "ECI_LINCMDREQUEST", "struct_e_c_i___l_i_n_c_m_d_r_e_q_u_e_s_t.html", [
      [ "dwReserved", "struct_e_c_i___l_i_n_c_m_d_r_e_q_u_e_s_t.html#a6ff0d907d251adb01a02e2299402f34d", null ],
      [ "dwVer", "struct_e_c_i___l_i_n_c_m_d_r_e_q_u_e_s_t.html#ae8695e2b3f0414f85bf784cdd93da2e7", null ],
      [ "sCmdHeader", "struct_e_c_i___l_i_n_c_m_d_r_e_q_u_e_s_t.html#aeebe62ca957b03df62f06dc56bcf1e46", null ],
      [ "u", "struct_e_c_i___l_i_n_c_m_d_r_e_q_u_e_s_t.html#a1a84bbe2050dd2f73686f2f17dd0bc6c", null ],
      [ "V0", "struct_e_c_i___l_i_n_c_m_d_r_e_q_u_e_s_t.html#a2df6b1b4f8a795b792aaf345fc838d82", null ]
    ] ],
    [ "ECI_LINCMDRESPONSE", "struct_e_c_i___l_i_n_c_m_d_r_e_s_p_o_n_s_e.html", [
      [ "dwReserved", "struct_e_c_i___l_i_n_c_m_d_r_e_s_p_o_n_s_e.html#a930ac54e5651ed17efdc5cb06814db4d", null ],
      [ "dwVer", "struct_e_c_i___l_i_n_c_m_d_r_e_s_p_o_n_s_e.html#a30435ed90f418f46e7e487fa4d964d14", null ],
      [ "sCmdHeader", "struct_e_c_i___l_i_n_c_m_d_r_e_s_p_o_n_s_e.html#ae795de93959884234df0edb25268a685", null ],
      [ "u", "struct_e_c_i___l_i_n_c_m_d_r_e_s_p_o_n_s_e.html#af9a1b1cec0a4b0207a39d70841b9335e", null ],
      [ "V0", "struct_e_c_i___l_i_n_c_m_d_r_e_s_p_o_n_s_e.html#a4ab0a55a4cfff5cf816042bca672e02d", null ]
    ] ],
    [ "ECI_LINFILTER", "struct_e_c_i___l_i_n_f_i_l_t_e_r.html", [
      [ "dwReserved", "struct_e_c_i___l_i_n_f_i_l_t_e_r.html#a9171e2c8df2010ec396f8c8acba89c29", null ],
      [ "dwVer", "struct_e_c_i___l_i_n_f_i_l_t_e_r.html#a525dc6368068e0bd44b032bda794b524", null ],
      [ "u", "struct_e_c_i___l_i_n_f_i_l_t_e_r.html#a0300e953d5fc12387972cb6054b41d02", null ],
      [ "V0", "struct_e_c_i___l_i_n_f_i_l_t_e_r.html#a8cd850a330ad9cfaa52eb6c60aed3e42", null ]
    ] ],
    [ "ECI_LIN_BITRATE_MAX", "group___lin_types.html#ga6140d9dda73dc87f5660c7b9a3b8fafd", null ],
    [ "ECI_LIN_BITRATE_MIN", "group___lin_types.html#gaaaa21d030851f4e5f88efd711b88ff42", null ],
    [ "ECI_LIN_BITRATE_UNDEF", "group___lin_types.html#gae5752073650778b65eaf75f4cef85727", null ],
    [ "ECI_LIN_MAX_6BIT_ID", "group___lin_types.html#gadb9dcf767fe37ccd80ad9a47bbac0451", null ],
    [ "e_LINBITRATES", "group___lin_types.html#gab6b33767bdd8277ad03fea8b6b5b91c7", [
      [ "ECI_LIN_BITRATE_AUTO", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7a8e3496b3aba7d113956611e021462f61", null ],
      [ "ECI_LIN_BITRATE_1000", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7abb75d178fa65769dbd699ee04cf2f8e6", null ],
      [ "ECI_LIN_BITRATE_1200", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7ade67a96e5ae25135677692ab2d5ba89c", null ],
      [ "ECI_LIN_BITRATE_2400", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7ad99bc62a45dac243e67b6f5cdbb3eab0", null ],
      [ "ECI_LIN_BITRATE_4800", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7a62a4af734c60b610a6f1705b8909ff8b", null ],
      [ "ECI_LIN_BITRATE_9600", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7aeeafcb46cc3565c4a8d373424ec9b546", null ],
      [ "ECI_LIN_BITRATE_10400", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7ae7f61ad532e0fcaf09942951349789a8", null ],
      [ "ECI_LIN_BITRATE_19200", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7a650ecb143c8658c41b6a53758f37ff27", null ],
      [ "ECI_LIN_BITRATE_20000", "group___lin_types.html#ggab6b33767bdd8277ad03fea8b6b5b91c7a9ad34b5a2901afeafeeacc5c0b66edf5", null ]
    ] ],
    [ "e_LINBUSC", "group___lin_types.html#gaa19af5ab37374ac49e25f70dbcb18fd1", [
      [ "ECI_LIN_BUSC_UNDEFINED", "group___lin_types.html#ggaa19af5ab37374ac49e25f70dbcb18fd1a1b840e8054230320a2effd8c9dc0373e", null ],
      [ "ECI_LIN_BUSC_STANDARD", "group___lin_types.html#ggaa19af5ab37374ac49e25f70dbcb18fd1a6db7101422708c6fc5d2a34eaae57c0a", null ]
    ] ],
    [ "e_LINCTRLCLASS", "group___lin_types.html#ga50fb4dda38752ef11c365ccf044f4fa1", [
      [ "ECI_LIN_CTRL_UNKNOWN", "group___lin_types.html#gga50fb4dda38752ef11c365ccf044f4fa1ad40ebf7f20c0f52a62c0d59801b05386", null ],
      [ "ECI_LIN_CTRL_GENERIC", "group___lin_types.html#gga50fb4dda38752ef11c365ccf044f4fa1a307f395e028a74de089dc72c34e30d6c", null ],
      [ "ECI_LIN_CTRL_USB_V2", "group___lin_types.html#gga50fb4dda38752ef11c365ccf044f4fa1a5a58345cebe09c47bd51563214776c39", null ],
      [ "ECI_LIN_CTRL_DCD", "group___lin_types.html#gga50fb4dda38752ef11c365ccf044f4fa1af61c832da3868a22017cb6d43dc1c548", null ],
      [ "ECI_LIN_CTRL_MAXVAL", "group___lin_types.html#gga50fb4dda38752ef11c365ccf044f4fa1a1e9b14dbf510622b22e26e078624fb33", null ]
    ] ],
    [ "e_LINCTRLFEATURE", "group___lin_types.html#gaa68956695bb66ec66a9fe24692aaa18e", [
      [ "ECI_LIN_FEATURE_UNDEFINED", "group___lin_types.html#ggaa68956695bb66ec66a9fe24692aaa18ea1b6cc5865563e63c58288e7f440176f9", null ],
      [ "ECI_LIN_FEATURE_MASTER", "group___lin_types.html#ggaa68956695bb66ec66a9fe24692aaa18eabda49ac35585e59b96d0f55d7e8f3b10", null ],
      [ "ECI_LIN_FEATURE_AUTORATE", "group___lin_types.html#ggaa68956695bb66ec66a9fe24692aaa18ea5572c628b1b970be70617e400c7dc977", null ],
      [ "ECI_LIN_FEATURE_ERRFRAME", "group___lin_types.html#ggaa68956695bb66ec66a9fe24692aaa18ea12dd0e9170ce01a330ea65ab225f0c90", null ],
      [ "ECI_LIN_FEATURE_BUSLOAD", "group___lin_types.html#ggaa68956695bb66ec66a9fe24692aaa18ea1b0ae043f7f5691a1926509f9fa39007", null ]
    ] ],
    [ "e_LINERROR", "group___lin_types.html#ga3f2e845b0fd17101edb455ff9be0075b", [
      [ "ECI_LIN_ERROR_BIT", "group___lin_types.html#gga3f2e845b0fd17101edb455ff9be0075bad82152b4a1de118feebafd7f41fdb2b4", null ],
      [ "ECI_LIN_ERROR_CHKSUM", "group___lin_types.html#gga3f2e845b0fd17101edb455ff9be0075baa2c23351b1337768587d636b4ab2c3e3", null ],
      [ "ECI_LIN_ERROR_PARITY", "group___lin_types.html#gga3f2e845b0fd17101edb455ff9be0075ba9856dd3fe7ebdf25fbb3a9e883e4c06d", null ],
      [ "ECI_LIN_ERROR_SLNORE", "group___lin_types.html#gga3f2e845b0fd17101edb455ff9be0075ba433c804cfa53e6b4e6bd9adcda8f051a", null ],
      [ "ECI_LIN_ERROR_SYNC", "group___lin_types.html#gga3f2e845b0fd17101edb455ff9be0075ba7177060fa5e883e121e1325d2cc78d83", null ],
      [ "ECI_LIN_ERROR_NOBUS", "group___lin_types.html#gga3f2e845b0fd17101edb455ff9be0075ba2ded08f4329983349122efc5ffd6eb23", null ],
      [ "ECI_LIN_ERROR_OTHER", "group___lin_types.html#gga3f2e845b0fd17101edb455ff9be0075bab6183b60520c502c8057d77b29b042e2", null ],
      [ "ECI_LIN_ERROR_WAKEUP", "group___lin_types.html#gga3f2e845b0fd17101edb455ff9be0075badf668b1a47182f328bb40e5055f6c99c", null ]
    ] ],
    [ "e_LININFO", "group___lin_types.html#ga56defd1ea86981da05298908e393a13a", [
      [ "ECI_LIN_INFO_START", "group___lin_types.html#gga56defd1ea86981da05298908e393a13aa4097140165899c7bd5e108ee3f2df76f", null ],
      [ "ECI_LIN_INFO_STOP", "group___lin_types.html#gga56defd1ea86981da05298908e393a13aa7ed098b1e4b75d10f2f0b71eee1b2dd4", null ],
      [ "ECI_LIN_INFO_RESET", "group___lin_types.html#gga56defd1ea86981da05298908e393a13aa73a998cb3daa4bb1e7cb6158979288fc", null ]
    ] ],
    [ "e_LINMSGFLAGS", "group___lin_types.html#ga8306534d090be6910db438061494190e", [
      [ "ECI_LIN_MSGFLAGS_DLC", "group___lin_types.html#gga8306534d090be6910db438061494190ea2768434b8988dd1ca423d16f526ae022", null ],
      [ "ECI_LIN_MSGFLAGS_OVR", "group___lin_types.html#gga8306534d090be6910db438061494190ea87a5b87c3c29f629aae2e27db9815c0a", null ],
      [ "ECI_LIN_MSGFLAGS_SOR", "group___lin_types.html#gga8306534d090be6910db438061494190ea2e1b69b19422f9ae9018a52caae06ae1", null ],
      [ "ECI_LIN_MSGFLAGS_ECS", "group___lin_types.html#gga8306534d090be6910db438061494190ead1ac17e1bbd72267e706aaf20c69b657", null ],
      [ "ECI_LIN_MSGFLAGS_IDO", "group___lin_types.html#gga8306534d090be6910db438061494190ea0ff346d729071f786cfaa16a5b08d7d7", null ]
    ] ],
    [ "e_LINMSGFLAGS2", "group___lin_types.html#gad5c3feb8f696fcf715ea329f65e089a0", [
      [ "ECI_LIN_MSGFLAGS2_BUF", "group___lin_types.html#ggad5c3feb8f696fcf715ea329f65e089a0a113ec6eba9171f829a950d6debeb7083", null ]
    ] ],
    [ "e_LINMSGTYPE", "group___lin_types.html#ga30b181d78c4500faa651beabb6053ea2", [
      [ "ECI_LIN_MSGTYPE_DATA", "group___lin_types.html#gga30b181d78c4500faa651beabb6053ea2a3c2179993c3ce886439dfd9be48ff6ca", null ],
      [ "ECI_LIN_MSGTYPE_INFO", "group___lin_types.html#gga30b181d78c4500faa651beabb6053ea2a9c2051b6b66e041a96825aa01d7b736e", null ],
      [ "ECI_LIN_MSGTYPE_ERROR", "group___lin_types.html#gga30b181d78c4500faa651beabb6053ea2aa14748a4348a73d008ab143d2cc68eea", null ],
      [ "ECI_LIN_MSGTYPE_STATUS", "group___lin_types.html#gga30b181d78c4500faa651beabb6053ea2a492dca3a0ad1562458c4e32625fea498", null ],
      [ "ECI_LIN_MSGTYPE_WAKEUP", "group___lin_types.html#gga30b181d78c4500faa651beabb6053ea2a4c9f919241418047598bd96ec8f56aca", null ],
      [ "ECI_LIN_MSGTYPE_TIMEOVR", "group___lin_types.html#gga30b181d78c4500faa651beabb6053ea2abf785b1cf8dfdfbfa47e5d995a829770", null ],
      [ "ECI_LIN_MSGTYPE_TIMERST", "group___lin_types.html#gga30b181d78c4500faa651beabb6053ea2a378b415c5ba934aa20a91c7366ff54a5", null ],
      [ "ECI_LIN_MSGTYPE_SLEEP", "group___lin_types.html#gga30b181d78c4500faa651beabb6053ea2a9285026361cc150e875155802e2c8e70", null ]
    ] ],
    [ "e_LINOPMODE", "group___lin_types.html#ga4d0bc41f740e5b7f3ff6604f9a4d9b4c", [
      [ "ECI_LIN_OPMODE_SLAVE", "group___lin_types.html#gga4d0bc41f740e5b7f3ff6604f9a4d9b4cabaa4ae01978c506d146be68053b7d0ea", null ],
      [ "ECI_LIN_OPMODE_MASTER", "group___lin_types.html#gga4d0bc41f740e5b7f3ff6604f9a4d9b4ca7740b2f6b953cd254bb769b4bca484eb", null ],
      [ "ECI_LIN_OPMODE_ERRFRAME", "group___lin_types.html#gga4d0bc41f740e5b7f3ff6604f9a4d9b4ca09967e0b4eacc68ff642ba1a0ab4d0e1", null ],
      [ "ECI_LIN_OPMODE_CACHED_STATUS", "group___lin_types.html#gga4d0bc41f740e5b7f3ff6604f9a4d9b4ca941d4c32b2fe8f7df93398e1e7dddfe2", null ]
    ] ],
    [ "e_LINSTATUS", "group___lin_types.html#gac0a995a852bb1513239ceeec62e32ed3", [
      [ "ECI_LIN_STATUS_OVRRUN", "group___lin_types.html#ggac0a995a852bb1513239ceeec62e32ed3a454ea179df54294a9847b0d4df37a8d0", null ],
      [ "ECI_LIN_STATUS_ININIT", "group___lin_types.html#ggac0a995a852bb1513239ceeec62e32ed3abfba592b0d5d9b8d5c56092519d27ba1", null ]
    ] ]
];