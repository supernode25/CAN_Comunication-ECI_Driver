var globals_eval =
[
    [ "e", "globals_eval.html", null ]
];