var struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e =
[
    [ "bBtReg0", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#a3ead3ffafdbd6cef67a1bbc359b85863", null ],
    [ "bBtReg1", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#a3978823c74b4812c6965e3b4af62657a", null ],
    [ "bExMode", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#aaaaaf9981d555235f51a62d5dbddb3af", null ],
    [ "bOpMode", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#a43ea70d8ac685f5fb064c7fd5104a474", null ],
    [ "bReserved", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#ad5f973d2d850f12bc2cbaaf4802db6b4", null ],
    [ "dwVer", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#af037da8e5f2cb04294a94c27cb052da8", null ],
    [ "sBtpFdr", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#ae1c64df5b276cc4c72f7649bbd1c59d0", null ],
    [ "sBtpSdr", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#a6af8ac5ccdb3da6b7c040640ee1060bc", null ],
    [ "u", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#ac8a4008a7e6826033e34d517c6015d2c", null ],
    [ "V0", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#a236f47fec817590fb50fe8b495c541cd", null ],
    [ "V1", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#ab9d25490613a9c70ef0ab4cd27a54938", null ],
    [ "V2", "struct_e_c_i___c_a_n_i_n_i_t_l_i_n_e.html#a1bdde28f5006454ba4f3d515c7feeb70", null ]
];