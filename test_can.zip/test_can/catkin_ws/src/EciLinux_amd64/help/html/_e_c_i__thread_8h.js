var _e_c_i__thread_8h =
[
    [ "ECI_SCHEDULER_SETTINGS", "struct_e_c_i___s_c_h_e_d_u_l_e_r___s_e_t_t_i_n_g_s.html", "struct_e_c_i___s_c_h_e_d_u_l_e_r___s_e_t_t_i_n_g_s" ],
    [ "ECI_CPU", "_e_c_i__thread_8h.html#a90e99942316d6674d3446243209b384b", null ],
    [ "ECI_CPU_ALL", "_e_c_i__thread_8h.html#adbcb757feb77d13c44e45b805d2b9bb2", null ],
    [ "ECI_MAX_CPU", "_e_c_i__thread_8h.html#a3ba4a89210c84b05bd92d85667c7fcd7", null ],
    [ "PECI_SCHEDULER_SETTINGS", "_e_c_i__thread_8h.html#a24bbc48347f82d3967c482023c288f0a", null ],
    [ "e_SCHEDPOLICY", "_e_c_i__thread_8h.html#a8fb6765b52413e22dd3d8aab4df15e2b", [
      [ "ECI_SCHED_NOCHANGE", "_e_c_i__thread_8h.html#a8fb6765b52413e22dd3d8aab4df15e2ba91677d0169ac9d03c5f8635a591fd7db", null ],
      [ "ECI_SCHED_FIFO", "_e_c_i__thread_8h.html#a8fb6765b52413e22dd3d8aab4df15e2ba36f0d440d5242abe373bc261c0a3af61", null ],
      [ "ECI_SCHED_RR", "_e_c_i__thread_8h.html#a8fb6765b52413e22dd3d8aab4df15e2baa22c05b879642e03bfe6e215e3191dd5", null ],
      [ "ECI_SCHED_OTHER", "_e_c_i__thread_8h.html#a8fb6765b52413e22dd3d8aab4df15e2baf4901d819c37f44319f9b67392e23ed4", null ]
    ] ]
];