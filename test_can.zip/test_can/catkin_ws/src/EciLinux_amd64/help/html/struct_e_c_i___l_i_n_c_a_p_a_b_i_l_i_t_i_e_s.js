var struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s =
[
    [ "dwClockFreq", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aa8121fa431924ca34fe3ccb4caa8cb8d", null ],
    [ "dwDtxDivisor", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#ac1565d6a1e12f4eff05fd4c99326521c", null ],
    [ "dwDtxMaxTicks", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aecf4fd05095cf268fa7d4d22039fc845", null ],
    [ "dwFeatures", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a9109141350e885037eab418b6c5f83e5", null ],
    [ "dwNoOfPrioQueues", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#ab195c014e95066ed0af02adfaa35a9de", null ],
    [ "dwTscDivisor", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a9e439b7e7eba6c7096c3d180916d583f", null ],
    [ "dwVer", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a9fdfd5079d9be6e2109f5925aa351f8a", null ],
    [ "u", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a42782f96de905d3716629a8ab9758df0", null ],
    [ "V0", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a6fd9acb4c3fe3cd588f33194844074f3", null ],
    [ "wBusCoupling", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aafabd30daaf601bf70922a47c72befda", null ],
    [ "wLinType", "struct_e_c_i___l_i_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aa09a90eeda0445dd2078da8fab0d60eb", null ]
];