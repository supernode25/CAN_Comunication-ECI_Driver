var modules =
[
    [ "ECI API Functions", "group___eci_api.html", "group___eci_api" ],
    [ "OS ECI Functions", "group___os_eci.html", "group___os_eci" ],
    [ "Hardware Structures and Types", "group___hw_types.html", "group___hw_types" ],
    [ "Controller Structures and Types", "group___ctrl_types.html", "group___ctrl_types" ],
    [ "CAN Structures and Types", "group___can_types.html", "group___can_types" ],
    [ "LIN Structures and Types", "group___lin_types.html", "group___lin_types" ],
    [ "Logging Structures and Types", "group___log_types.html", "group___log_types" ]
];