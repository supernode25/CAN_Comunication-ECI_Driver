var struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s =
[
    [ "dwCanClkFreq", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a75f9d0098443e7b99e7b9172a9c0d65a", null ],
    [ "dwClockFreq", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a682359b4fd8fddc3a8cbae9f9f300a82", null ],
    [ "dwDtxDivisor", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a9f6043064f4b0da7cd2c89a6d6103856", null ],
    [ "dwDtxMaxTicks", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a705b5847db3537a0c7a1783343c64ba7", null ],
    [ "dwFeatures", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a62b011601498001ff5e8ad93ae7059a9", null ],
    [ "dwNoOfPrioQueues", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a204dcd8fb99b1973cd4f24b32e472de5", null ],
    [ "dwPriClkFreq", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a9362839c8df7fef0394a10827ca57b6f", null ],
    [ "dwTscDivisor", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#ab47369f56affab89ed3d571767f82ff5", null ],
    [ "dwVer", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#aebde11487aebe7b0d358d10c63df15a5", null ],
    [ "sFdrRangeMax", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#ad3a5c04425c4b1fd63ddc78b15eae6f0", null ],
    [ "sFdrRangeMin", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a34f27f8beec91b9b4c1943d12eb2c9e5", null ],
    [ "sSdrRangeMax", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a98196952013cacad33907a21ca338e45", null ],
    [ "sSdrRangeMin", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#afbd7d30e40f06137efa28edbea4fdfea", null ],
    [ "u", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a79f1dd70587813eee92546bee61db082", null ],
    [ "V0", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a1985ebbffb53dec80eaaf29a9a502e8d", null ],
    [ "V1", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#afe60991238736f4ffa9742d98d784549", null ],
    [ "wBusCoupling", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#a74253df463a5a92fe7dceab750097d3a", null ],
    [ "wCanType", "struct_e_c_i___c_a_n_c_a_p_a_b_i_l_i_t_i_e_s.html#af5616e3db0c32a3f3887c84c67cbac03", null ]
];