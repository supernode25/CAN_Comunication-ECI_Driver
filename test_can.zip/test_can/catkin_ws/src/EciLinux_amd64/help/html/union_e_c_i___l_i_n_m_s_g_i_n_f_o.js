var union_e_c_i___l_i_n_m_s_g_i_n_f_o =
[
    [ "bFlags", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#abc4e5781992abd9c44c8a8cd188799eb", null ],
    [ "bFlags2", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a0fa86bb16ea8508d5e9e9612524366ec", null ],
    [ "Bits", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#ae52a4dd9abd16f521178b359f95cc403", null ],
    [ "bReserved2", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a051d9974559ced3f7f3c808113428a97", null ],
    [ "bType", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#ac5d8ce5335e8de9cca5775ff4142a66a", null ],
    [ "buf", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#ad992827322d48912f86df94a0b4113db", null ],
    [ "Bytes", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#aa8e10da198dec3cd511022d6543df73b", null ],
    [ "dlc", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a943df07fdcbbd98f84d5fcd6a330ee73", null ],
    [ "ecs", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#aad3d874d34aaa3c0eacd1d6e540e35c1", null ],
    [ "ido", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#af79952fc6435450e066eaaef3776b373", null ],
    [ "ovr", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a6fa38dfbf737e517fc0e04c95f1e6e3f", null ],
    [ "res", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a6434aa59fd81f18b4b56b65538e576fc", null ],
    [ "res2", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a2640c2baacc0cc8c81855e78d43e7abc", null ],
    [ "sor", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a4fdd23f72564fcf7240e886a239957f2", null ],
    [ "type", "union_e_c_i___l_i_n_m_s_g_i_n_f_o.html#a5ddc95442826206b852343eecf59c92d", null ]
];