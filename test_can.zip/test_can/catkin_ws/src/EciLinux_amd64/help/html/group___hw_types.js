var group___hw_types =
[
    [ "ECI_PCI_SETTINGS", "struct_e_c_i___p_c_i___s_e_t_t_i_n_g_s.html", [
      [ "dwReserved", "struct_e_c_i___p_c_i___s_e_t_t_i_n_g_s.html#a7a75d79adbd7e9b5f224f7c9e3410142", null ],
      [ "dwVer", "struct_e_c_i___p_c_i___s_e_t_t_i_n_g_s.html#aaac7cd6a358c225e931479f60f7fef9c", null ],
      [ "sSchedSettings", "struct_e_c_i___p_c_i___s_e_t_t_i_n_g_s.html#a156822b689d064270ca4fe0a6f8f6004", null ],
      [ "u", "struct_e_c_i___p_c_i___s_e_t_t_i_n_g_s.html#a4dc4d10e3038ae5fc0696a7d26ec0897", null ],
      [ "V0", "struct_e_c_i___p_c_i___s_e_t_t_i_n_g_s.html#ad5639a1e956297dbb6edffbf8f5e3315", null ],
      [ "V1", "struct_e_c_i___p_c_i___s_e_t_t_i_n_g_s.html#a5392ff75fcfe726b7aedc8e5f37d5a07", null ]
    ] ],
    [ "ECI_ISA_SETTINGS", "struct_e_c_i___i_s_a___s_e_t_t_i_n_g_s.html", [
      [ "bInterrupt", "struct_e_c_i___i_s_a___s_e_t_t_i_n_g_s.html#ae732dd0aef6b137a73931f94c111a5e9", null ],
      [ "dwAddress", "struct_e_c_i___i_s_a___s_e_t_t_i_n_g_s.html#a51e2e9d8d1615be3851e8ae7fb7b0a75", null ],
      [ "dwVer", "struct_e_c_i___i_s_a___s_e_t_t_i_n_g_s.html#a393118b3e89feeb4a71e8c6051eb4890", null ],
      [ "sSchedSettings", "struct_e_c_i___i_s_a___s_e_t_t_i_n_g_s.html#a853e93cdf0d91f021c58967d2463e937", null ],
      [ "u", "struct_e_c_i___i_s_a___s_e_t_t_i_n_g_s.html#a443bd2c7d0fcfe5c01d27ffbffabc4bd", null ],
      [ "V0", "struct_e_c_i___i_s_a___s_e_t_t_i_n_g_s.html#a179dcba946f7bb878426e0854b6f4a34", null ],
      [ "V1", "struct_e_c_i___i_s_a___s_e_t_t_i_n_g_s.html#aafa3e317837f2396e021fcdfb9d63d14", null ]
    ] ],
    [ "ECI_USB_SETTINGS", "struct_e_c_i___u_s_b___s_e_t_t_i_n_g_s.html", [
      [ "dwReserved", "struct_e_c_i___u_s_b___s_e_t_t_i_n_g_s.html#a6701d2851223530abe22425cff039fdc", null ],
      [ "dwVer", "struct_e_c_i___u_s_b___s_e_t_t_i_n_g_s.html#a76068906764cb905c9d5624a948829ca", null ],
      [ "sRxSchedSettings", "struct_e_c_i___u_s_b___s_e_t_t_i_n_g_s.html#a4016efda16e547218918a21b4b0b94e0", null ],
      [ "sTxSchedSettings", "struct_e_c_i___u_s_b___s_e_t_t_i_n_g_s.html#af3d80958478eb536a524ca70bae446a0", null ],
      [ "u", "struct_e_c_i___u_s_b___s_e_t_t_i_n_g_s.html#a0e62fb62599906d46a50a0539be317f9", null ],
      [ "V0", "struct_e_c_i___u_s_b___s_e_t_t_i_n_g_s.html#a3c3142bbc426f6ad67e70c1f4fa4d3d2", null ],
      [ "V1", "struct_e_c_i___u_s_b___s_e_t_t_i_n_g_s.html#a4e91d4b45c6f9a03cff790c9f812bb64", null ]
    ] ],
    [ "ECI_IP_SETTINGS", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html", [
      [ "adwPort", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#a62147c38a36850014c7d110100e773b7", null ],
      [ "dwProtocol", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#a741ac9702e59edf0902b45c43737148c", null ],
      [ "dwVer", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#ab038706b0fc28ed7dc04f99f5b036f1d", null ],
      [ "sSchedSettings", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#afeb5bb1eb7512b3eaa3b7b214d8a845d", null ],
      [ "szIpAddress", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#a0bc0103b542947e5f497ce9be800fac1", null ],
      [ "szPassword", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#a58c4946e3b90cce4529633d66bdab40c", null ],
      [ "u", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#a9d5397965c744d902a95ea2528e72ad1", null ],
      [ "V0", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#abef065d3b6263561a8e7c994e35ccc62", null ],
      [ "V1", "struct_e_c_i___i_p___s_e_t_t_i_n_g_s.html#aa10724e433865010e561ed3194d957d5", null ]
    ] ],
    [ "ECI_HW_PARA", "struct_e_c_i___h_w___p_a_r_a.html", [
      [ "dwFlags", "struct_e_c_i___h_w___p_a_r_a.html#aa46bc95abf75ac1fdd4c67538d68ef6e", null ],
      [ "sIpSettings", "struct_e_c_i___h_w___p_a_r_a.html#a36e7d7ec58982c3f4ef96208cd239aaa", null ],
      [ "sIsaSettings", "struct_e_c_i___h_w___p_a_r_a.html#af3fc2bb904fa02436ab79bcc843ac0cf", null ],
      [ "sPciSettings", "struct_e_c_i___h_w___p_a_r_a.html#af890eb8760f23af3c3efed232b5f1a47", null ],
      [ "sUsbSettings", "struct_e_c_i___h_w___p_a_r_a.html#a46579539311ed3ae56789033d0f2ac72", null ],
      [ "u", "struct_e_c_i___h_w___p_a_r_a.html#ae375f48ecc26cb863355b0fa35ce88fc", null ],
      [ "wHardwareClass", "struct_e_c_i___h_w___p_a_r_a.html#a25b8dbfcdd8db904ff47351efb8519ae", null ]
    ] ],
    [ "ECI_HW_INFO", "struct_e_c_i___h_w___i_n_f_o.html", [
      [ "abBmVersion", "struct_e_c_i___h_w___i_n_f_o.html#a081e24d4fede6565da41ac400240b873", null ],
      [ "abFwVersion", "struct_e_c_i___h_w___i_n_f_o.html#a9993fcd30efefc76886a8dea777e3f70", null ],
      [ "abHwVersion", "struct_e_c_i___h_w___i_n_f_o.html#ae9926ded48e2ea944fbcd8877de5c299", null ],
      [ "adwApiVersion", "struct_e_c_i___h_w___i_n_f_o.html#a991699e426bb0b6af3f59506d729bfd1", null ],
      [ "dwCtrlCount", "struct_e_c_i___h_w___i_n_f_o.html#a2c1af9b3708ec4b80bc6148dcbe71a77", null ],
      [ "dwDevId", "struct_e_c_i___h_w___i_n_f_o.html#ad7fddc10c3ac7552225de1e191696987", null ],
      [ "dwVer", "struct_e_c_i___h_w___i_n_f_o.html#adf3d33c540f7aa32b52c834e0874623c", null ],
      [ "sCtrlInfo", "struct_e_c_i___h_w___i_n_f_o.html#aca74a2f12e447190c79a73952f3a80ce", null ],
      [ "szFwIdentification", "struct_e_c_i___h_w___i_n_f_o.html#a84fc08e05b94239caf9455413b4b944a", null ],
      [ "szHwBoardType", "struct_e_c_i___h_w___i_n_f_o.html#a6acdf96535aa647e21380512d1b8b79c", null ],
      [ "szHwSerial", "struct_e_c_i___h_w___i_n_f_o.html#a1059bdd654e665d6945446e6ab245bac", null ],
      [ "u", "struct_e_c_i___h_w___i_n_f_o.html#aac7a928818acb961ad7f44c63a5dfac0", null ],
      [ "V0", "struct_e_c_i___h_w___i_n_f_o.html#acfcbb7a991654e7af431496c12a5b650", null ],
      [ "V1", "struct_e_c_i___h_w___i_n_f_o.html#aab87714d85f7e2bd64e298a084931fc4", null ]
    ] ],
    [ "ECI_MAXBOARDCOUNT", "group___hw_types.html#gac3bbebbad3466f0230b3199a873a231e", null ],
    [ "e_HWCLASS", "group___hw_types.html#gab7c972121be0dcecc25fee9fc2ee4974", [
      [ "ECI_HW_UNDEFINED", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974a6885b67fb4d6519517008608806a3e7f", null ],
      [ "ECI_HW_PCI", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974ad545eed42bca602ecd0eccad612a6e90", null ],
      [ "ECI_HW_ISA", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974acb27c77c2c33f6756a22a3b50502ba11", null ],
      [ "ECI_HW_USB", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974a57861716b576ca308fe64ebf02546c00", null ],
      [ "ECI_HW_IP", "group___hw_types.html#ggab7c972121be0dcecc25fee9fc2ee4974a52cdb0d7511bf361688c80fde0d9b0ec", null ]
    ] ],
    [ "e_LIBSTATES", "group___hw_types.html#ga465a1b9b5e0ea4e85b1f9e707073a4f5", [
      [ "ECI_UNINITIALIZED", "group___hw_types.html#gga465a1b9b5e0ea4e85b1f9e707073a4f5a1bebdf0399db5d8d0510b23880f735c8", null ],
      [ "ECI_INITIALIZED", "group___hw_types.html#gga465a1b9b5e0ea4e85b1f9e707073a4f5ae270ea84190c6a5767c450cc49dba301", null ],
      [ "ECI_CONFIGURED", "group___hw_types.html#gga465a1b9b5e0ea4e85b1f9e707073a4f5acfb076408b6be369048d64d6c84af7b5", null ]
    ] ]
];