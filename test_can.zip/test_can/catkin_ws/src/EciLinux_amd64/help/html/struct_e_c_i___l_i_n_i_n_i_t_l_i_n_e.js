var struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e =
[
    [ "bOpMode", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a6d6ba0c51e10683f2b0d1d2330e58847", null ],
    [ "bReserved", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a977d2340e1cb70c3c122a1a105f97f4a", null ],
    [ "dwVer", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#aa7181b9b406cafc0b3c0fe0f05079506", null ],
    [ "u", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a9f4cc2fde56cf9d2a1ebd093deb6eb51", null ],
    [ "V0", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a4ca9cc9820d5cc6175997f43f641d264", null ],
    [ "wBitrate", "struct_e_c_i___l_i_n_i_n_i_t_l_i_n_e.html#a1a24d5443f110fe311595223cdafcb63", null ]
];