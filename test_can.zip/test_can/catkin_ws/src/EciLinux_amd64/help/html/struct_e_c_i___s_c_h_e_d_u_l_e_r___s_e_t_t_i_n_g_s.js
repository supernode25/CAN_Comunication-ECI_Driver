var struct_e_c_i___s_c_h_e_d_u_l_e_r___s_e_t_t_i_n_g_s =
[
    [ "dwCpuAffinity", "struct_e_c_i___s_c_h_e_d_u_l_e_r___s_e_t_t_i_n_g_s.html#a5f93dda68efb83c0a9c56b76b6e6aa3f", null ],
    [ "dwSchedulerPolicy", "struct_e_c_i___s_c_h_e_d_u_l_e_r___s_e_t_t_i_n_g_s.html#af5e2f8cd4c76ce2d86715f0a9dac5c13", null ],
    [ "dwSchedulerPriority", "struct_e_c_i___s_c_h_e_d_u_l_e_r___s_e_t_t_i_n_g_s.html#a288aa115ac2521549cb296e8ceba2700", null ]
];