var group___log_types =
[
    [ "ECI_LOG_ENTRY", "struct_e_c_i___l_o_g___e_n_t_r_y.html", [
      [ "dwFlags", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a52dba1ea5ffa09a672ebc4ef6d45c83f", null ],
      [ "dwLostCount", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a26150a17eb553dcaf53956ba82b906f1", null ],
      [ "dwSource", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a5e8b1fb06ff8b9602192f9009273b170", null ],
      [ "dwTime", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a47a767fc5fee2ef11d4a35b1ed7d8a82", null ],
      [ "dwVer", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a4eddad98fe7c007746cf744786d66edd", null ],
      [ "szLog", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a8729a7c50eeb136b4be869c8750b6703", null ],
      [ "u", "struct_e_c_i___l_o_g___e_n_t_r_y.html#a0c13dca7b7396d987c97f135301b5efd", null ],
      [ "V0", "struct_e_c_i___l_o_g___e_n_t_r_y.html#accf5d41668e23c0f3d4bca922c29963d", null ]
    ] ],
    [ "ECI_LOG_CONFIG", "struct_e_c_i___l_o_g___c_o_n_f_i_g.html", [
      [ "dwLogMode", "struct_e_c_i___l_o_g___c_o_n_f_i_g.html#acd38936ae3f82a7ca69bbb7738e4a95c", null ],
      [ "dwLogSize", "struct_e_c_i___l_o_g___c_o_n_f_i_g.html#ad45ec1125f9bc8ae05a8c355df08db51", null ],
      [ "dwLogSources", "struct_e_c_i___l_o_g___c_o_n_f_i_g.html#a0d390ec0d65899216ca5df5617eac6a1", null ],
      [ "dwVer", "struct_e_c_i___l_o_g___c_o_n_f_i_g.html#a9c1d823005306e8faf4717c2481b6ae9", null ],
      [ "u", "struct_e_c_i___l_o_g___c_o_n_f_i_g.html#afd2547f684e2b30581ebe2a4ea6463d1", null ],
      [ "V0", "struct_e_c_i___l_o_g___c_o_n_f_i_g.html#a4d5a8b1c78121c487cf60090322295a6", null ]
    ] ],
    [ "e_ECI_LOGGING_FLAGS", "group___log_types.html#ga44db6a5a2da0f4896ccb8dafd321add2", [
      [ "ECI_LOGGING_FLAG_NONE", "group___log_types.html#gga44db6a5a2da0f4896ccb8dafd321add2afc8f03dd990441f3eec163de4bda260e", null ],
      [ "ECI_LOGGING_FLAG_OVERRUN", "group___log_types.html#gga44db6a5a2da0f4896ccb8dafd321add2aa98fd760c285ea192b878baabe125f54", null ]
    ] ],
    [ "e_ECI_LOGGING_MODE", "group___log_types.html#ga76315f4adaa39239bc47df38efcfd113", [
      [ "ECI_LOGGING_MODE_UNDEFINED", "group___log_types.html#gga76315f4adaa39239bc47df38efcfd113a50d8df67ea1116882b062d2fce761798", null ],
      [ "ECI_LOGGING_MODE_FIFO", "group___log_types.html#gga76315f4adaa39239bc47df38efcfd113a2f7358e82f604f8f2bdbe1fc0ddc40db", null ]
    ] ],
    [ "e_ECI_LOGGING_SOURCE", "group___log_types.html#ga70bebd459538f2c051bac91d9dade38a", [
      [ "ECI_LOGGING_SOURCE_NONE", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aac92c587e7bca544f3749529b7e4d7903", null ],
      [ "ECI_LOGGING_SOURCE_INFO_ALL", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa3bf545ade053af8c95b1ff9ca6ff431d", null ],
      [ "ECI_LOGGING_SOURCE_INFO_ECI_API", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa40e8a83706383f934ae508fcb5205e58", null ],
      [ "ECI_LOGGING_SOURCE_WARNING_ALL", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa9e7be1990f8c11ca5915e4c9a840b226", null ],
      [ "ECI_LOGGING_SOURCE_WARNING_TS", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa8a2f06bb73bbd17694cb1bae2963616c", null ],
      [ "ECI_LOGGING_SOURCE_ERROR_ALL", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa15e04aebac049b256225963903d449e5", null ],
      [ "ECI_LOGGING_SOURCE_ERROR_CCI", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa38dc77c93697e226e1f4635539a0363e", null ],
      [ "ECI_LOGGING_SOURCE_DEBUG_ALL", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa404265405cdb666312980f64f86f9631", null ],
      [ "ECI_LOGGING_SOURCE_DEBUG_TS", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa5080127a5b935777ee9514b641b91b53", null ],
      [ "ECI_LOGGING_SOURCE_DEBUG_DEVMSG", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aa21489eaf85aa7c0a436a77f0671882ba", null ],
      [ "ECI_LOGGING_SOURCE_ALL", "group___log_types.html#gga70bebd459538f2c051bac91d9dade38aaf793dad5924bb98d7b94c66d4284bba8", null ]
    ] ]
];