#define _CRT_SECURE_NO_WARNINGS
#define GLOG_NO_ABBREVIATED_SEVERITIES

#define TEST_MODE 0

#include <iostream>
#include <stdlib.h>

#include <opencv2/opencv.hpp>

#include <fcntl.h>
#include <linux/input.h>
#include <unistd.h>
#include <stdlib.h>
#include <termios.h>
#include <stdio.h>
#include <stdarg.h>
#include <pthread.h>

#include "ECI_function.h"

#undef min
#undef max

int main(int argc,
		 char **argv,
		 char **envp)
{
   ECI_RESULT hResult = ECI_OK;

  OS_Printf(">> Linux ECI API Demo program <<\n\n");

  //*** ECI Demo for USB-to-CAN V2
  hResult = EciDemo113();


  OS_Printf("-> Closing Linux ECI API Demo program <-\n");

  return hResult;
}
