#ifndef CR
#define CR 0x0D
#endif



class Soosung
{
public:

	bool is_opened;
	IPCv4* m_ipc;
	float steering_angle_now, steering_angle_r_now, velocity_now;


private:

	struct Param
	{
		float wheel_gear_ratio;
		float body_length;
		float wheel_size;

		float RPM2VEL; //rpm to mm/s
		float VEL2RPM; // mm/s to rpm

		short MAX_RPM;
		float MAX_Angle;

		std::string serialport;
	};

	float r2d, d2r;
	Logger logger;

	std::mutex angle_mtx, velocity_mtx;
	std::mutex target_angle_r_mtx, target_RPM_mtx;
	float target_angle_r, target_RPM;

	bool prev_driving_time_init;	
	Time prev_driving_time;

	Time thread_read_time, thread_write_time;
	std::thread thread_read, thread_write;

	bool EMS, AutoMode;
	ECI eci;
	std::mutex ECI_mtx;

	Timer odo_pub_timer;
	Odo nowRobot;

	void steering_beat(std::vector<char>& data)
	{
//		for(int i=0; i<(int)data.size(); i++)
//			printf("%d ", data[i]);
//		printf("\n");
	}

	void driving_beat(std::vector<char>& data)
	{
		char stats = data[0];
//		if(stats == 4) printf("stopped\n");
//		else if(stats == 5) printf("operating\n");
	}

	void get_steering_angle(char* data)
	{
		float angle;
		memcpy(&angle, data, sizeof(char)*4);

		float off_set = 0.55f / 180.0f * CV_PI;

		angle_mtx.lock();
		steering_angle_r_now = angle - off_set;
		steering_angle_now = angle * r2d;
		angle_mtx.unlock();
	}
	
	void get_driving_status(char* data)
	{
		short RPM;
		memcpy(&RPM, data, sizeof(char)*2);

//		RPM = RPM * 100 / 108;
		float RPM_f = (float)RPM * 100.0f / 108.0f;
		RPM = (short)RPM_f;

		bool mode = data[2] & 1 >> 0;
		bool emergency = data[2] & 1 >> 1;
		bool forward = data[2] & 1 >> 2;
		bool reverse = data[2] & 1 >> 3;


//		target_RPM_mtx.lock();
//		RPM = target_RPM;	
//		target_RPM_mtx.unlock();

		float vel = 0;
		velocity_mtx.lock();
		velocity_now = (float)RPM * param.RPM2VEL;
		if(reverse) velocity_now = -velocity_now;

		vel = velocity_now;
		velocity_mtx.unlock();

		AutoMode = mode;
		EMS = emergency;


//		printf("%02x %02x %02x %02x \n", data[0], data[1], data[2], data[3]);

//		printf("vel: %f RPM: %d mode: %d, em: %d, f: %d, r: %d\n"
//			, velocity_now, (int)RPM, (int)mode, (int)emergency, (int)forward, (int)reverse);	


		Time now;
		now.set_now();
		if(prev_driving_time_init == false)	
		{
			prev_driving_time_init = true;
			prev_driving_time = now;
			odo_pub_timer.tic();
		}

		double dt = now - prev_driving_time;
		prev_driving_time = now;

		float d = vel*(float)dt;

		float center_d = 0.0f;
		float r = 0.0f;

		angle_mtx.lock();
		float steering_angle_r = steering_angle_r_now;
		angle_mtx.unlock();

		if(steering_angle_r == 0.0f)
		{
			center_d = d;
		}
		else
		{
			float a = param.body_length / sin(steering_angle_r);
			float b = a * cos(steering_angle_r);
			r =  d/a;

			center_d = b*r;
		}

		if(!std::isfinite(center_d))
		{
			printf(" infinite error\n");
			return;
		}

		Odo move_odo(center_d, 0, r*r2d);
		Odo new_odo = nowRobot.addMotion(move_odo);

		nowRobot.x = new_odo.x;
		nowRobot.y = new_odo.y;
		nowRobot.th = new_odo.th;

		odo_pub_timer.toc();
		if(odo_pub_timer.get_ms() < 30.0)
			return;

		odo_pub_timer.tic();

		Msg::Odometer out_msg;
		out_msg.x = new_odo.x;
		out_msg.y = new_odo.y;
		out_msg.th = new_odo.th;
		out_msg.data_time.set_now();

	//	printf("cona: %lf %lf %lf %f %f\n", out_msg.x, out_msg.y, out_msg.th, steering_angle_r, d);
		if(m_ipc != nullptr)
			m_ipc->publish<Msg::Odometer>("Odometer_cona", out_msg);

	}

	void setAngle(int ID, float radian)
	{
		float max_angle = 70.0f;
		float dgree = radian / CV_PI * 180.0f;
		if(dgree <-max_angle) dgree = -max_angle;
		if(dgree > max_angle) dgree = max_angle;

		angle_mtx.lock();
		float angle_now = steering_angle_now;
		angle_mtx.unlock();

		float degree_gap = (dgree - angle_now) / 1.0f;

		if(fabs(dgree - angle_now) < 3.0f)
			degree_gap = (dgree - angle_now);
//		if(-1.0f < degree_gap && degree_gap < 0.0f)
//			degree_gap = -1.0f;
//		if(0.0f < degree_gap && degree_gap < 1.0f)
//			degree_gap = 1.0f;

		float new_dgree = degree_gap + angle_now;

		char data[8] = {};
		radian = new_dgree / 180.0f * CV_PI;
		memcpy(data, &radian, sizeof(float));

		if(AutoMode && !EMS) eci.send(ID, data, 8);
//		send_data(ID, data, 8);
	}

	void setRPM(unsigned int ID, short rpm)
	{
		if(-300 < rpm && rpm < 300 && rpm != 0)
		{
			if(rpm < 0) rpm = -300;
			else rpm = 300;
		}

		char data[4] = {};

		bool farward = rpm > 0;
		unsigned short abs_rpm = abs(rpm);

		memcpy(data, &abs_rpm, 2);

		char temp = data[1];
		data[0] =  data[1];
		data[1] =  temp;

		if(farward) data[2] = 1;
		else data[3] = 1;

		if(AutoMode && !EMS) eci.send(ID, data, 8);

//		logger.push_back(Logger::Warning, cv::format("RPM: %d", (int)rpm));
	}

	 
	void thread_read_function(void)
	{
		std::string read_string;
		Rate runner(50);
		logger.push_back(Logger::Info, "read thread is started");

		while(1)
		{
			thread_read_time.set_now();

			int ID = 0;
			int data_size = 0;
			char data[8] = {};

			if(is_opened)
			{
				ECI_mtx.lock();
				if(!eci.receive(ID, data, data_size))
					logger.push_back(Logger::Warning, "no received data from robot");
				ECI_mtx.unlock();
			}

			if(ID == 207) get_steering_angle(data);
			else if(ID == 205) get_driving_status(data);
//			else if(ID == 707) steering_beat(data);
//			else if(ID == 705) driving_beat(data);
			else continue;
		}
	}

	void thread_write_function(void)
	{
		int rd = -1;
		Rate runner(50);
		logger.push_back(Logger::Info, "write thread is started");

		while(1)
		{
			thread_write_time.set_now();

			bool stop_signal = false;
			if(target_angle_r == 0.0 && target_RPM == 0.0)
				stop_signal = true;

			if(!stop_signal)
			{
				target_angle_r_mtx.lock();
				setAngle(187, target_angle_r);
				target_angle_r_mtx.unlock();
			}

			target_RPM_mtx.lock();
			setRPM(123, target_RPM);
			target_RPM_mtx.unlock();

			runner.sleep();
		}
	}

	void thread_run(void)
	{
		std::string read_string;
		int rd = -1;
		Rate rate_temp(500);
		while(1)
		{
			Time now;
			now.set_now();

			double read_dt = now - thread_read_time;
			if(read_dt > 3.0)
			{
				logger.push_back(Logger::Error, "read thread is stopped. restart");
				pthread_t pt = thread_read.native_handle();
				pthread_cancel(pt);
				thread_write.detach();
				thread_read = std::thread(&Soosung::thread_read_function, this);
			}

			double write_dt = now - thread_write_time;
			if(write_dt > 3.0)
			{
				logger.push_back(Logger::Error, "read write is stopped. restart");
				pthread_t pt = thread_write.native_handle();
				pthread_cancel(pt);
				thread_write.detach();
				thread_write = std::thread(&Soosung::thread_write_function, this);
			}

			rate_temp.sleep();	
		}
	}

public:
	Param param;
	std::thread thread;

	Soosung(void)
		: m_ipc(nullptr), steering_angle_now(0), steering_angle_r_now(0), target_angle_r(0.0f), target_RPM(0.0f)
			, prev_driving_time_init(false), is_opened(false), AutoMode(false), EMS(true)
	{
		r2d = 180.0f / 3.141592f;
		d2r = 3.141592f / 180.0f;
	}

	bool connect(void)
	{
		if(!TEST_MODE) is_opened = eci.open();

		thread_read_time.set_now();
		thread_write_time.set_now();
		
		thread_read = std::thread(&Soosung::thread_read_function, this);
		thread_write = std::thread(&Soosung::thread_write_function, this);
		thread = std::thread(&Soosung::thread_run, this);

		if(!TEST_MODE) return is_opened;
		else
		{
			printf("TEST_MODE is on\n");
			return true;
		}
	}

	void move(double t_vel, double r_vel, bool precise_steering = false, double t_vel_rate = 1.0)
	{
//		if(t_vel != 0 && r_vel != 0)
//			logger.push_back(Logger::Info, cv::format("move: %lf %lf", t_vel, r_vel));

		float target_steering_radian = 0.0;
		float wheel_vel = 0.0;
		if(fabs(r_vel) > 0.01)
		{
			float r = (float)r_vel * d2r;

			float b = (float)t_vel / r;
			float a = std::sqrt(b*b + param.body_length*param.body_length);
			if(r < 0) a = -a;
			float d = a*r;
			if(t_vel < 0) d = -d;
			target_steering_radian = asin(param.body_length / a);
			wheel_vel = d;

		}
		else
		{
			wheel_vel = (float)(t_vel);
		}


		angle_mtx.lock();
		float angle_gap = target_steering_radian - steering_angle_r_now;
		angle_mtx.unlock();

		float vel_rate_variance = 30.0f *d2r;
//		float vel_rate_variance = 50.0f *d2r;
		if(precise_steering)
		{
			vel_rate_variance = 5.0f *d2r;
		}

		float vel_rate = exp(-angle_gap*angle_gap / 2.0f / vel_rate_variance / vel_rate_variance);

		target_angle_r_mtx.lock();
		target_angle_r = target_steering_radian;
		target_angle_r_mtx.unlock();

		target_RPM_mtx.lock();
		target_RPM = t_vel_rate*vel_rate*wheel_vel*param.VEL2RPM;
		target_RPM_mtx.unlock();
	}
};

class Robot
{
private:
public:
	struct ReferPath_Info
	{
		Odo absol_odo_from_origin;
		Odo absol_odo_from_robot, grid_odo_from_robot;
		int idx;
		bool is_begin;
		bool is_end;
		bool executable;

		ReferPath_Info() {};
		ReferPath_Info(Odo& realpath_, int idx_, bool is_begin_, bool is_end_)
		: absol_odo_from_origin(realpath_.x, realpath_.y, realpath_.th), 
		idx(idx_), is_begin(is_begin_), is_end(is_end_), executable(true) {};
	};

	IPCv4* m_ipc;
	Logger logger;

	float prev_target_angle;
	int following_mode;
	double navi_vel_rate;
	double path_length, remain_length;
	double deadrecording;
	bool lost_flag;

	std::mutex nowRobot_mtx;
	Time nowRobot_data_time;
	Odo nowRobot;

	std::mutex referPath_mtx;
	std::vector<ReferPath_Info> referPath;
	std::vector<ReferPath_Info> detourPath;

	Msg::Grid grid_info;
	std::mutex grid_mtx;
	cv::Mat grid, distance_grid;

	std::vector<std::string> message;

	int prev_closest_idx;
	float getClearance(float col, float row, float th, bool draw=false);
	float getLocalPathClearance(float base_x, float base_y, float base_th, float target_x, float target_y, float target_th
		, bool draw=false);
	void referPath_update(std::vector<ReferPath_Info>& refer_path);
	bool gen_vel_with_referPath(std::vector<ReferPath_Info>& refer_path);
	bool gen_vel_with_referPath2(std::vector<ReferPath_Info>& refer_path, double& obstacle_dist);
	bool gen_vel_with_detourPath(std::vector<ReferPath_Info>& refer_path);
	bool gen_vel(std::vector<ReferPath_Info>& refer_path);

	void drawRobot(cv::Mat &output, double x, double y, double th, cv::Scalar color, double size);

	CRT crt;

//public:
	struct Param
	{
		double real_circle_distance;
		double joy_max_t_vel;
		double joy_max_r_vel;

		double angleGap;
		double real_path_following_mergin;

		float min_clearance;
		
		float detour;

		float robot_size_start_x, robot_size_end_x;
		float robot_size_start_y, robot_size_end_y;
		
		float robot_size_start_col_grid, robot_size_end_col_grid;
		float robot_size_start_row_grid, robot_size_end_row_grid;
		
		double max_tran_vel;
		double max_rot_vel;

		bool ignore_obstacle_when_start;
		std::vector<int> ignore_list;
		
		bool ignore_y_error;
		std::vector<int> ignore_y_error_list;
	};
	Param param;

	Msg::cona_navistatus navi_status;

	Soosung ss;

	Odo grid_start, grid_goal;
	int goal_idx_in_refer;


	void run_planning(void);

	std::vector<std::pair<cv::Mat, std::mutex*>> plot;
	cv::Mat planning_draw;

	bool joy_vel;
	double output_t_vel_joy, output_r_vel_joy;
	double output_t_vel, output_r_vel;
	bool output_precise_joy, output_precise;

	Robot(IPCv4* ipc_);
	void odo_callback(Msg::Odometer* msg);
	void joy_callback(Msg::Joy* msg);
	void grid_callback(Msg::Grid* msg);
	void navi_callback(Msg::Navigation* msg);
	void robot_input_callback(Msg::Robot_input* msg);
};

Robot::Robot(IPCv4* ipc_)
	: m_ipc(ipc_), joy_vel(0), prev_target_angle(0)
{
	ss.m_ipc = m_ipc;
	output_t_vel_joy = 0.0;
	output_r_vel_joy = 0.0;
	output_t_vel = 0.0;
	output_r_vel = 0.0;
	output_precise_joy = false;
	output_precise = false;


	plot.push_back(std::pair<cv::Mat, std::mutex*>(cv::Mat(), new std::mutex));
	plot.push_back(std::pair<cv::Mat, std::mutex*>(cv::Mat(), new std::mutex));
	plot.push_back(std::pair<cv::Mat, std::mutex*>(cv::Mat(), new std::mutex));
//	plot.push_back(cv::Mat());
//	plot.push_back(cv::Mat());

	std::memset(&grid_info, 0, sizeof(Msg::Grid));
	grid_info.col = 500;
	grid_info.row = 500;
	grid_info.robot_col = 250;
	grid_info.robot_row = 350;
	grid_info.mm2pixel = 50.0f / 1000.0f;
};

float Robot::getLocalPathClearance(float base_x, float base_y, float base_th, float target_x, float target_y, float target_th, bool draw)
{
	float dx = target_x - base_x;
	float dy = target_y - base_y;
	float dth = target_th - base_th;

	while(1)
	{	
		if(dth < -180.0f) dth += 360.0f;
		else if(dth > 180.0f) dth -= 360.0f;
		else break;
	}

	int sampling_num = 0;
	if(base_x == target_x && base_y == target_y && base_th == target_th)
	{
		return getClearance(base_x, base_y, base_th, draw);
	}
	else if(base_x == target_x && base_y == target_y)
	{
		float abs_dth = dth;
		if(abs_dth < 0) abs_dth = -abs_dth;

		sampling_num = (int)(abs_dth / 10.0f);
	}
	else
	{
		float dist = std::sqrt(dx*dx + dy*dy);

		float min_gap = std::max(param.min_clearance * grid_info.mm2pixel, 10.0f);

		sampling_num = (int)(dist / min_gap);	
	}

	if(	base_x < 0 || base_x >= distance_grid.cols ||  base_y < 0 || base_y >= distance_grid.rows)
		return 0;

	float min_val = getClearance(base_x, base_y, base_th, draw);
	
	if(	target_x >= 0 && target_x < distance_grid.cols && target_y >= 0 && target_y < distance_grid.rows)
		min_val = std::min(getClearance(target_x, target_y, target_th, draw), min_val);

	if(sampling_num <= 0) return min_val;

	sampling_num++;

	for(int i=1; i<(int)sampling_num; i++)
	{
		float rate = (float)i / (float)sampling_num;

		float x = base_x + rate*dx;
		float y = base_y + rate*dy;
		float th = base_th + rate*dth;

		if(x < 0 || x >= distance_grid.cols || y < 0 || y >= distance_grid.rows)
			continue;

		min_val = std::min(getClearance(x, y, th, draw), min_val);
	}
	
	return min_val;
}

//float Robot::getLocalPathClearance(float base_x, float base_y, float target_x, float target_y)
//{
//    float min_val = INFINITY;
//
//    if (distance_grid.empty())
//    {
//		message.push_back("Error: No distance_map");
//        return param.min_clearance;
//    }
//
//    if (abs(base_x-target_x)<1.0f && abs(base_y-target_y)<1.0f)
//    {
//        return distance_grid.at<float>(base_y, base_x) / grid_info.mm2pixel;
//    }
//
//    float dx;
//    if (target_x - base_x < 0) dx = -1;
//    else if (target_x - base_x > 0) dx = 1;
//    else dx = 0;
//
//    float dy;
//    if (target_y - base_y < 0) dy = -1;
//    else if (target_y - base_y > 0) dy = 1;
//    else dy = 0;
//
//    int x = (int)base_x;
//    int y = (int)base_y;
//
//	bool fail = false;
//    if ((int)target_x != (int)base_x)
//    {
//        float a = ((float)target_y - (float)base_y) / ((float)target_x - (float)base_x);
//
//		while (1)
//        {
//            float c = distance_grid.at<float>(y, x);
//            if (c < min_val || !std::isfinite(min_val)) min_val = c;
//
//            float val = a * (float)(x - base_x) - (float)(y - base_y);
//			if(dy > 0)
//				val = -val;
//
//			if (val >= 0) x += dx;
//			else y += dy;
//
//			if (std::abs(x - (int)target_x) < 2 && std::abs(y - (int)target_y) < 2)
//			{
//				break;
//			}
//
//            if (x < 0 || x >= distance_grid.cols)
//			{
//				fail = true;	
//				break;
//			}
//
//			
//            if (y < 0 || y >= distance_grid.rows)
//			{
//				fail = true;	
//				break;
//			}
//        }
//    }
//    else
//    {
//        while (1)
//        {
//            float c = distance_grid.at<float>(y, x);
//            if (c < min_val || !std::isfinite(min_val)) min_val = c;
//
//            y += dy;
//
//            if (x == (int)target_x && y == (int)target_y) break;
//            if (x < 0 || x >= distance_grid.cols)
//			{
//				fail = true;	
//				break;
//			}	
//            if (y < 0 || y >= distance_grid.rows) 
//			{
//				fail = true;	
//				break;
//			}
//		}
//    }
//
//	if(fail)
//	{
//		printf("Error in getLocalPathClearance\n");
//	}
//
//    return min_val / grid_info.mm2pixel;
//}

//cv::Mat DEBUG_PLOT;
float Robot::getClearance(float col, float row, float th, bool draw)
{
	if(distance_grid.empty()) return 0.0f;

	float p1 = param.robot_size_start_y * grid_info.mm2pixel;
	float p2 = param.robot_size_end_y * grid_info.mm2pixel;
	float p3 = param.robot_size_start_x * grid_info.mm2pixel;
	float p4 = param.robot_size_end_x * grid_info.mm2pixel;

	float p5 = p1 / 2.0f;

	float r = -(th+180.0f) / 180.0f * (float)CV_PI;

	cv::Point2f p1_(p1*cos(r) - p3*sin(r) + col, p1*sin(r) + p3*cos(r) + row);
	cv::Point2f p2_(p1*cos(r) - p4*sin(r) + col, p1*sin(r) + p4*cos(r) + row);
	cv::Point2f p3_(p2*cos(r) - p3*sin(r) + col, p2*sin(r) + p3*cos(r) + row);
	cv::Point2f p4_(p2*cos(r) - p4*sin(r) + col, p2*sin(r) + p4*cos(r) + row);

	cv::Point2f p5_(p1*cos(r) - p4*sin(r)*0.5f + col, p1*sin(r) + p4*cos(r)*0.5f + row);
	cv::Point2f p6_(p2*cos(r) - p4*sin(r)*0.5f + col, p2*sin(r) + p4*cos(r)*0.5f + row);

	float min_val = distance_grid.at<float>((int)row, (int)col);

	if(p1_.x >= 0.0f && p1_.x < (float)distance_grid.cols && p1_.y >= 0.0f && p1_.y < (float)distance_grid.rows)
	{
		min_val = std::min(min_val, distance_grid.at<float>((int)p1_.y, (int)p1_.x));
	}

	if(p2_.x >= 0.0f && p2_.x < (float)distance_grid.cols && p2_.y >= 0.0f && p2_.y < (float)distance_grid.rows)
	{
		min_val = std::min(min_val, distance_grid.at<float>((int)p2_.y, (int)p2_.x));
	}

	if(p3_.x >= 0.0f && p3_.x < (float)distance_grid.cols && p3_.y >= 0.0f && p3_.y < (float)distance_grid.rows)
	{
		min_val = std::min(min_val, distance_grid.at<float>((int)p3_.y, (int)p3_.x));
	}

	if(p4_.x >= 0.0f && p4_.x < (float)distance_grid.cols && p4_.y >= 0.0f && p4_.y < (float)distance_grid.rows)
	{
		min_val = std::min(min_val, distance_grid.at<float>((int)p4_.y, (int)p4_.x));
	}
	
	if(p5_.x >= 0.0f && p5_.x < (float)distance_grid.cols && p5_.y >= 0.0f && p5_.y < (float)distance_grid.rows)
	{
		min_val = std::min(min_val, distance_grid.at<float>((int)p5_.y, (int)p5_.x));
	}

	if(p6_.x >= 0.0f && p6_.x < (float)distance_grid.cols && p6_.y >= 0.0f && p6_.y < (float)distance_grid.rows)
	{
		min_val = std::min(min_val, distance_grid.at<float>((int)p6_.y, (int)p6_.x));
	}


	if(!planning_draw.empty() && draw)
	{
		cv::Scalar color(0, 255, 0);
		int thickness = 1;
		if(min_val / grid_info.mm2pixel < (float)param.min_clearance)
		{
			color = cv::Scalar(0, 0, 255);
			thickness = 1;
		}

		cv::line(planning_draw, p1_, p2_, color, thickness);
		cv::line(planning_draw, p2_, p4_, color, thickness);
		cv::line(planning_draw, p4_, p3_, color, thickness);
		cv::line(planning_draw, p3_, p1_, color, thickness);
	}

//	cv::line(DEBUG_PLOT, p1_, cv::Point(col, row), cv::Scalar(0, 0, 0), 1);
//	cv::line(DEBUG_PLOT, p2_, cv::Point(col, row), cv::Scalar(0, 0, 0), 1);
//	cv::line(DEBUG_PLOT, p3_, cv::Point(col, row), cv::Scalar(0, 0, 0), 1);
//	cv::line(DEBUG_PLOT, p4_, cv::Point(col, row), cv::Scalar(0, 0, 0), 1);

	return min_val / grid_info.mm2pixel;	
}

void Robot::referPath_update(std::vector<ReferPath_Info>& refer_path)
{
	nowRobot_mtx.lock();
	Odo now_robotodo(nowRobot.x, nowRobot.y, nowRobot.th);
	nowRobot_mtx.unlock();

	for(int i=0; i<(int)refer_path.size(); i++)
	{
		Odo absol_odo_from_origin(
				refer_path[i].absol_odo_from_origin.x,
				refer_path[i].absol_odo_from_origin.y,
				refer_path[i].absol_odo_from_origin.th);

		Odo absol_odo_from_robot = now_robotodo.getMotion(absol_odo_from_origin);

		Odo grid_odo(
				grid_info.robot_col - grid_info.mm2pixel*absol_odo_from_robot.y,
				grid_info.robot_row - grid_info.mm2pixel*absol_odo_from_robot.x,
				absol_odo_from_robot.th);

		refer_path[i].absol_odo_from_robot.x = absol_odo_from_robot.x;
		refer_path[i].absol_odo_from_robot.y = absol_odo_from_robot.y;
		refer_path[i].absol_odo_from_robot.th = absol_odo_from_robot.th;
		refer_path[i].grid_odo_from_robot.x = grid_odo.x;
		refer_path[i].grid_odo_from_robot.y = grid_odo.y;
		refer_path[i].grid_odo_from_robot.th = grid_odo.th;
	}
}

bool Robot::gen_vel_with_referPath2(std::vector<ReferPath_Info>& refer_path, double& obstacle_dist)
{
	if(refer_path.size() == 0)
	{
		printf("there is no refer_path\n");
		return false;
	}

	bool draw = !planning_draw.empty(); 

    double closest_path_distance = -1.0;
    double farest_path_distance = -1.0;
    int closest_idx_in = -1;
    int closest_idx_out = -1;
	bool find_far_idx_in = true;
	int far_idx_in = -1;
	bool find_logest_idx = true;
	int longest_idx = -1;

	bool obstacle_is_found = false;

	bool start_corner = false;
	std::vector<int> corners;

	bool ignore_obstalce = false;

	referPath_update(refer_path);	

	for(int i=0; i<(int)refer_path.size(); i++)
	{
		Odo absol_odo_from_origin(
				refer_path[i].absol_odo_from_origin.x,
				refer_path[i].absol_odo_from_origin.y,
				refer_path[i].absol_odo_from_origin.th);

		Odo absol_odo_from_robot(
			refer_path[i].absol_odo_from_robot.x,
			refer_path[i].absol_odo_from_robot.y,
			refer_path[i].absol_odo_from_robot.th);

		Odo grid_odo(
				refer_path[i].grid_odo_from_robot.x,
				refer_path[i].grid_odo_from_robot.y,
				refer_path[i].grid_odo_from_robot.th);

		bool is_in = true;
        if (grid_odo.x < 0 || grid_odo.x >= grid.cols) is_in = false;
        if (grid_odo.y < 0 || grid_odo.y >= grid.rows) is_in = false;

		double gap_dist = absol_odo_from_robot.getDist() + abs(absol_odo_from_robot.th)/180.0*200.0;
		if(gap_dist < closest_path_distance || closest_path_distance < 0)
        {
            closest_path_distance = gap_dist;
			if(is_in) closest_idx_in = i;
			else closest_idx_out = i;
        }

		if(is_in == false && longest_idx != -1)
			find_logest_idx = false;
		
		if(longest_idx < closest_idx_in)
		{
			longest_idx = closest_idx_in;
			farest_path_distance = -1.0;
		}

		if(gap_dist > farest_path_distance || farest_path_distance < 0.0)
		{
			farest_path_distance = gap_dist;
			if(is_in == true && find_logest_idx == true)
				longest_idx = i;
		}

		if(gap_dist < param.real_circle_distance)
		{
			 if(find_far_idx_in) far_idx_in = i;
		}
		else if(find_far_idx_in && far_idx_in != -1) find_far_idx_in = false;

		if(refer_path[i].is_begin) 
		{
			if(refer_path[i].absol_odo_from_robot.getDist() < 1000.0 && param.ignore_obstacle_when_start)
			{
				for(int ignore_idx=0; ignore_idx<(int)param.ignore_list.size(); ignore_idx++)
					if(refer_path[i].idx == param.ignore_list[ignore_idx] || 
							refer_path[i].idx == param.ignore_list[ignore_idx]+1
						)
					{
						ignore_obstalce = true;
						break;
					}
			}
		}


		if(is_in)
		{
			float clearance = getClearance((float)grid_odo.x, (float)grid_odo.y, (float)grid_odo.th);
			if(clearance < param.min_clearance && !ignore_obstalce)
			{
				obstacle_is_found = true;
				refer_path[i].executable = false;
			}
		}

		if(i+1 < (int)refer_path.size())
		{
			Odo next_motion = absol_odo_from_origin.getMotion(refer_path[i+1].absol_odo_from_origin); 

			bool is_start_or_end = refer_path[i].is_begin || refer_path[i+1].is_end;

			if(next_motion.getDist() < 100 && abs(next_motion.th) > 10 && is_start_or_end)
				start_corner = true;
			else
				start_corner = false;
			
			if(start_corner)
				corners.push_back(i);
		}
	}

	if(ignore_obstalce)
		printf("ignore_obstalce\n");

	if(corners.size() < 2) corners.clear();

	if(draw)
	{
		cv::circle(planning_draw, cv::Point(grid_info.robot_col, grid_info.robot_row), param.real_circle_distance*grid_info.mm2pixel, 
			cv::Scalar(0, 0, 255));

		for(int i=0; i<(int)refer_path.size(); i++)
		{
			cv::Scalar color(0, 255, 0);
			if(!refer_path[i].executable) color = cv::Scalar(0, 0, 255);

			drawRobot(planning_draw, 
				refer_path[i].grid_odo_from_robot.x, 
				refer_path[i].grid_odo_from_robot.y, 
				refer_path[i].grid_odo_from_robot.th, 
				color, 15);
			
			if(i >= closest_idx_in && i <= far_idx_in)
				cv::circle(planning_draw, 
					cv::Point2d(refer_path[i].grid_odo_from_robot.x, 
								refer_path[i].grid_odo_from_robot.y), 
					5, cv::Scalar(0, 0, 255), 2);

			if(i >= closest_idx_in && i <= longest_idx)
				cv::circle(planning_draw, 
					cv::Point2d(refer_path[i].grid_odo_from_robot.x, 
								refer_path[i].grid_odo_from_robot.y), 
					5, cv::Scalar(0, 0, 255), 1);
		}

		for(int i=0; i<(int)corners.size(); i++)
		{
			int idx = corners[i];
			cv::circle(planning_draw, 
				cv::Point((int)refer_path[idx].grid_odo_from_robot.x, (int)refer_path[idx].grid_odo_from_robot.y), 
				15, cv::Scalar(125, 125, 0), -1);
		}
	}	

	if(far_idx_in == -1) far_idx_in = closest_idx_in;
	if(longest_idx == -1) longest_idx = closest_idx_in;

	//if(obstacle_is_found && param.detour>0.0f)
	//{
	//	if(!detourPath.empty()) message.push_back("Use detourPath");	
	//	else message.push_back("Make detourPath");	
	//	return false;
	//}
	

	if (closest_idx_in == -1 && closest_idx_out == -1)
    {
        message.push_back("could not find any path");

		navi_status.status = Msg::cona_navistatus::ERROR;
		strcpy(navi_status.log, std::string("there is no path").c_str());
        return false;
    }
	else if(closest_idx_in == -1)
	{
        message.push_back("No visible refer path. Make virtual target");
		Odo& target = refer_path[closest_idx_out].grid_odo_from_robot;  

		double margin = 10.0;	
		double x = std::min(std::max(target.x, margin), grid.cols - margin);
		double y = std::min(std::max(target.y, margin), grid.rows - margin);

		double col_rate = (x - (double)grid_info.robot_col) / (target.x - (double)grid_info.robot_col);
		double row_rate = (y - (double)grid_info.robot_row) / (target.y - (double)grid_info.robot_row);
		double rate = std::min(col_rate, row_rate);
	
		Odo gap_odo = grid_start.getMotion(target);
		gap_odo.x *= rate;	
		gap_odo.y *= rate;	

		Odo new_target = grid_start.addMotion(gap_odo);
		grid_goal.x = new_target.x;
		grid_goal.y = new_target.y;
		grid_goal.th = new_target.th;
		goal_idx_in_refer = -1;

		navi_status.status = Msg::cona_navistatus::LOST;
		strcpy(navi_status.log, std::string("No visible refer path").c_str());
		return false;
	}

	bool found_corner = false;
	for (int i = closest_idx_in; i < (int)refer_path.size(); i++)
	{
		if(refer_path[i].absol_odo_from_robot.getDist() > param.real_circle_distance) break;

		bool temp_found_corner = false;
		for(int j=0; j<(int)corners.size(); j++)
		{
			if(i == corners[j])
			{
				temp_found_corner = true;
			}
		}

		if(found_corner == true && temp_found_corner == false)
		{
			far_idx_in = i;
			break;
		}

		found_corner = temp_found_corner;
		
		if(found_corner) break;
	}

	Odo dist_far2last = refer_path[far_idx_in].absol_odo_from_robot.getMotion(refer_path.back().absol_odo_from_robot);
	bool last_path_is_the_target = false;
	if(dist_far2last.getDist() < 100.0) last_path_is_the_target = true;

//	bool angle_mode = (far_idx_in == (int)refer_path.size() -1) || found_corner;
	bool angle_mode = last_path_is_the_target || found_corner;

	int temp_goal_idx = -1;

	if(angle_mode)
	{
		if(far_idx_in < closest_idx_in)
		{
			printf("far_idx_in idx error %d\n", far_idx_in);
			far_idx_in = closest_idx_in+1;
			if(far_idx_in>=refer_path.size())
				far_idx_in = (int)refer_path.size()-1;
		}

		message.push_back("angle_mode");
		temp_goal_idx = far_idx_in;
		for(int i=far_idx_in; i>= closest_idx_in; i--)
		{
			Odo& gap = refer_path[i].absol_odo_from_robot;
			if(gap.getDist() < param.real_circle_distance
				&& abs(gap.th) < param.angleGap)
					break;
			
			temp_goal_idx = i;
		}
	}
	else
	{
		message.push_back("normal_mode");
		float grid_path_mergin = param.real_path_following_mergin * grid_info.mm2pixel;
		float bx = (float)grid_info.robot_col;
		float by = (float)grid_info.robot_row;
	
//		for (int i = closest_idx_in; i <= far_idx_in; i++)
		for (int i = closest_idx_in; i <= longest_idx; i++)
		{
			double dist = refer_path[i].absol_odo_from_robot.getDist();

			temp_goal_idx = i;	
			if(dist > 1000.0 && fabs(refer_path[i].absol_odo_from_robot.th) > 20) break;
			else if(fabs(refer_path[i].absol_odo_from_robot.th) > 60) break;

			continue;

			float tx = (float)refer_path[i].grid_odo_from_robot.x;
			float ty = (float)refer_path[i].grid_odo_from_robot.y;
			float t_th = (float)refer_path[i].grid_odo_from_robot.th;

			float a = ty - by;
			float b = -(tx - bx);
			float c = -bx*ty + tx*by;
			float ab = sqrt(a*a + b*b);	

//			bool found_corner = false;
//			for(int j=0; j<(int)corners.size(); j++)
//			{
//				if(i == corners[j]) found_corner = true;
//				if(found_corner) break;
//			}

			bool clear = true;	
			for(int j=closest_idx_in; j<=i; j++)
			{
				float nx = (float)refer_path[j].grid_odo_from_robot.x;
				float ny = (float)refer_path[j].grid_odo_from_robot.y;
				float d = abs(a*nx + b*ny + c) / ab;

				double angle_ratio = std::max(std::min(1.0 - abs(refer_path[j].absol_odo_from_robot.th)/20.0, 1.0), 0.2);
				if(refer_path[j].absol_odo_from_robot.getDist() <= param.real_circle_distance) angle_ratio = 1.0;

				float mergin = (float)(angle_ratio * grid_path_mergin);
				if(d > mergin)
				{
					clear = false;
					break;
				}

				if(draw)
				{
					cv::circle(planning_draw, 
						cv::Point((int)refer_path[j].grid_odo_from_robot.x, (int)refer_path[j].grid_odo_from_robot.y), 
						mergin, cv::Scalar(255, 0, 0), 1);
//					cv::circle(planning_draw, 
//						cv::Point((int)refer_path[j].grid_odo_from_robot.x, (int)refer_path[j].grid_odo_from_robot.y), 
//						d, cv::Scalar(255, 255, 0), 3);
				}
			}
	
			if((t_th < -param.angleGap || t_th > param.angleGap) && 
					refer_path[i].absol_odo_from_robot.getDist() > param.real_circle_distance) clear = false;

			temp_goal_idx = i;	
			if(!clear) 
			{
				if(i == closest_idx_in) temp_goal_idx = far_idx_in;
				break;
			}


			if(found_corner) break;
		}

//		if(temp_goal_idx == far_idx_in && 0) 
//			for(int i=far_idx_in; i>=closest_idx_in; i--)
//			{
//				double angle = referPath[i].th;
//				if(angle < param.angleGap && angle > -param.angleGap)
//					break;
//				temp_goal_idx = i;
//			}
	}

	if (temp_goal_idx == -1)
	{
		message.push_back("Error. No temp_goal_idx");

		navi_status.status = Msg::cona_navistatus::ERROR;
		strcpy(navi_status.log, std::string("cannot determine a subgoal").c_str());

		return false;
	}

	float clearance = getLocalPathClearance((float)grid_info.robot_col, (float)grid_info.robot_row, 0.0f,
			(float)refer_path[temp_goal_idx].grid_odo_from_robot.x, 
			(float)refer_path[temp_goal_idx].grid_odo_from_robot.y, 
			(float)refer_path[temp_goal_idx].grid_odo_from_robot.th);

	bool find_target_in_refer = true;
	if (clearance < (float)param.min_clearance && !ignore_obstalce)
	{
		bool found_detour_path = false;
		if(param.detour>0.0f) 
		{
			find_target_in_refer = false;

			int detour_path_goal = temp_goal_idx;
			for(detour_path_goal; detour_path_goal<(int)refer_path.size(); detour_path_goal++)
				if(refer_path[detour_path_goal].executable) break;

			if(detour_path_goal < (int)refer_path.size())
			{
				found_detour_path = true;

				grid_mtx.lock();
				crt.input.binary_grid = grid.clone();
				grid_mtx.unlock();
				crt.input.mm2pixel = grid_info.mm2pixel;
				crt.input.start_x = grid_info.robot_col;
				crt.input.start_y = grid_info.robot_row;
				crt.input.start_th = 0.0f;
				crt.input.goal_x = (float)refer_path[detour_path_goal].grid_odo_from_robot.x;
				crt.input.goal_y = (float)refer_path[detour_path_goal].grid_odo_from_robot.y;
				crt.input.goal_th = (float)refer_path[detour_path_goal].grid_odo_from_robot.th;
				crt.input.draw = false;

				if(!crt.planning())
					logger.push_back(Logger::Error, crt.output.error_log);	

				detourPath.clear();
				Odo grid_robot(crt.input.start_x, crt.input.start_y, 0.0);
				double r2d = 180.0/CV_PI;

				nowRobot_mtx.lock();
				Odo now_robotodo(nowRobot.x, nowRobot.y, nowRobot.th);
				nowRobot_mtx.unlock();

				for(int i=0; i<crt.output.path.cols; i++)
				{
					detourPath.push_back(ReferPath_Info());
					ReferPath_Info& target = detourPath.back();

					target.grid_odo_from_robot.x = crt.output.path.at<float>(0, i);
					target.grid_odo_from_robot.y = crt.output.path.at<float>(1, i);
					target.grid_odo_from_robot.th = crt.output.path.at<float>(2, i)*r2d;

					target.absol_odo_from_robot.x = 
						(grid_info.robot_row-crt.output.path.at<float>(1, i))/grid_info.mm2pixel;
					target.absol_odo_from_robot.y = 
						(grid_info.robot_col-crt.output.path.at<float>(0, i))/grid_info.mm2pixel;
					target.absol_odo_from_robot.th = target.grid_odo_from_robot.th;
			
					Odo absol_odo = now_robotodo.addMotion(target.absol_odo_from_robot);
					target.absol_odo_from_origin.x = absol_odo.x;
					target.absol_odo_from_origin.y = absol_odo.y;
					target.absol_odo_from_origin.th = absol_odo.th;

					target.executable = false;
				}

				message.push_back(cv::format("found %d detour path node",crt.output.path.cols));
				return 0;
			}
		}

		if(!found_detour_path)
		{
			bool found_closeser_target = false;
			int found_closeser_target_idx = -1;

			for(int i=temp_goal_idx; i>=closest_idx_in; i--)
			{
				clearance = getLocalPathClearance((float)grid_start.x, (float)grid_start.y, (float)grid_start.th,
				(float)refer_path[i].grid_odo_from_robot.x, 
				(float)refer_path[i].grid_odo_from_robot.y, 
				(float)refer_path[i].grid_odo_from_robot.th);

				if(clearance > (float)param.min_clearance && refer_path[i].absol_odo_from_robot.getDist() > 500.0 )	
				{
					found_closeser_target_idx = i;
					found_closeser_target = true;
					break;
				}
			}

			if(found_closeser_target)
			{
				obstacle_dist = refer_path[found_closeser_target_idx].absol_odo_from_robot.getDist();

//				grid_goal.x = .x;
//				grid_goal.y = refer_path[found_closeser_target_idx].grid_odo_from_robot.y;
//				grid_goal.th = refer_path[found_closeser_target_idx].grid_odo_from_robot.th;
//				temp_goal_idx = found_closeser_target_idx;
//				message.push_back("found_closeset target.");
//				goal_idx_in_refer = found_closeser_target_idx;
			}
			else
			{
				obstacle_dist = 0.0;
				return false;
			}
		}
	}
	else
	{
		grid_goal.x = refer_path[temp_goal_idx].grid_odo_from_robot.x;
		grid_goal.y = refer_path[temp_goal_idx].grid_odo_from_robot.y;
		grid_goal.th = refer_path[temp_goal_idx].grid_odo_from_robot.th;
		goal_idx_in_refer = temp_goal_idx;
	}

	cv::Point2f output_p(refer_path[temp_goal_idx].grid_odo_from_robot.x, refer_path[temp_goal_idx].grid_odo_from_robot.y);

	if(1)
	{
		if(0 < temp_goal_idx && temp_goal_idx < (int)refer_path.size()-1)
		{
			if(refer_path[temp_goal_idx].absol_odo_from_robot.getDist() > param.real_circle_distance)
			{
				cv::Point2f p1(refer_path[temp_goal_idx].grid_odo_from_robot.x, refer_path[temp_goal_idx].grid_odo_from_robot.y);
				cv::Point2f p2(refer_path[temp_goal_idx-1].grid_odo_from_robot.x, refer_path[temp_goal_idx-1].grid_odo_from_robot.y);

				float step = 20.0;
				float dx = (p1.x-p2.x) / step;
				float dy = (p1.y-p2.y) / step;
				float max_dist = param.real_circle_distance * grid_info.mm2pixel;
				for(int i=0; i<(int)step; i++)
				{
					cv::Point2f p3(p2.x+((float)i*dx), p2.y+((float)i*dy));
					float dist_x = p3.x - grid_info.robot_col;
					float dist_y = p3.y - grid_info.robot_row;
					float dist = std::sqrt(dist_x*dist_x + dist_y*dist_y);
					if(dist > max_dist)
					{
						output_p = p3;
						break;
					}
				}
			}

			if(fabs(refer_path[temp_goal_idx].absol_odo_from_robot.th) > param.angleGap)
			{
				cv::Point2f p1(refer_path[temp_goal_idx].grid_odo_from_robot.x, refer_path[temp_goal_idx].grid_odo_from_robot.y);
				cv::Point2f p2(refer_path[temp_goal_idx-1].grid_odo_from_robot.x, refer_path[temp_goal_idx-1].grid_odo_from_robot.y);
				double angle_gap = refer_path[temp_goal_idx].grid_odo_from_robot.th - refer_path[temp_goal_idx-1].grid_odo_from_robot.th;

				float step = 20.0;
				float dx = (p1.x-p2.x) / step;
				float dy = (p1.y-p2.y) / step;
				float dth = (float)angle_gap / step;
				for(int i=0; i<(int)step; i++)
				{
					cv::Point2f p3(p2.x+((float)i*dx), p2.y+((float)i*dy));
					float now_angle = (float)refer_path[temp_goal_idx-1].grid_odo_from_robot.th + (float)i*dth;

					if(now_angle > param.angleGap || now_angle < -param.angleGap)
					{
						output_p = p3;

//						printf("angle inter: %lf %f %lf\n", 
//							refer_path[temp_goal_idx-1].grid_odo_from_robot.th,
//							now_angle,
//							refer_path[temp_goal_idx].grid_odo_from_robot.th);

						break;
					}
				}

			}
		}
	}

	grid_goal.x = output_p.x;
	grid_goal.y = output_p.y;

	if(draw)
	{
		cv::line(planning_draw, cv::Point2f(grid_start.x, grid_start.y), cv::Point2f(grid_goal.x, grid_goal.y), 
			cv::Scalar(255, 0, 0), 2);
		
		drawRobot(planning_draw, grid_goal.x, grid_goal.y, grid_goal.th, cv::Scalar(255, 0, 0), 50);
	}	

	return true;
}

bool Robot::gen_vel_with_referPath(std::vector<ReferPath_Info>& refer_path)
{
	if(refer_path.size() == 0)
	{
		printf("there is no refer_path\n");
		return false;
	}

	bool draw = !planning_draw.empty(); 

    double closest_path_distance = -1.0;
    double farest_path_distance = -1.0;
    int closest_idx_in = -1;
    int closest_idx_out = -1;
	bool find_far_idx_in = true;
	int far_idx_in = -1;
	bool find_logest_idx = true;
	int longest_idx = -1;

	bool obstacle_is_found = false;

	bool start_corner = false;
	std::vector<int> corners;

	bool ignore_obstalce = false;

	referPath_update(refer_path);	

	for(int i=0; i<(int)refer_path.size(); i++)
	{
		Odo absol_odo_from_origin(
				refer_path[i].absol_odo_from_origin.x,
				refer_path[i].absol_odo_from_origin.y,
				refer_path[i].absol_odo_from_origin.th);

		Odo absol_odo_from_robot(
			refer_path[i].absol_odo_from_robot.x,
			refer_path[i].absol_odo_from_robot.y,
			refer_path[i].absol_odo_from_robot.th);

		Odo grid_odo(
				refer_path[i].grid_odo_from_robot.x,
				refer_path[i].grid_odo_from_robot.y,
				refer_path[i].grid_odo_from_robot.th);

		bool is_in = true;
        if (grid_odo.x < 0 || grid_odo.x >= grid.cols) is_in = false;
        if (grid_odo.y < 0 || grid_odo.y >= grid.rows) is_in = false;

		double gap_dist = absol_odo_from_robot.getDist() + abs(absol_odo_from_robot.th)/180.0*200.0;
		if(gap_dist < closest_path_distance || closest_path_distance < 0)
        {
            closest_path_distance = gap_dist;
			if(is_in) closest_idx_in = i;
			else closest_idx_out = i;
        }

		if(is_in == false && longest_idx != -1)
			find_logest_idx = false;
		
		if(longest_idx < closest_idx_in)
		{
			longest_idx = closest_idx_in;
			farest_path_distance = -1.0;
		}

		if(gap_dist > farest_path_distance || farest_path_distance < 0.0)
		{
			farest_path_distance = gap_dist;
			if(is_in == true && find_logest_idx == true)
				longest_idx = i;
		}

		if(gap_dist < param.real_circle_distance)
		{
			 if(find_far_idx_in) far_idx_in = i;
		}
		else if(find_far_idx_in && far_idx_in != -1) find_far_idx_in = false;

		if(refer_path[i].is_begin) 
		{
			if(refer_path[i].absol_odo_from_robot.getDist() < 1000.0 && param.ignore_obstacle_when_start)
			{
				for(int ignore_idx=0; ignore_idx<(int)param.ignore_list.size(); ignore_idx++)
					if(refer_path[i].idx == param.ignore_list[ignore_idx] || 
							refer_path[i].idx == param.ignore_list[ignore_idx]+1
						)
					{
						ignore_obstalce = true;
						break;
					}
			}
		}


		if(is_in)
		{
			float clearance = getClearance((float)grid_odo.x, (float)grid_odo.y, (float)grid_odo.th);
			if(clearance < param.min_clearance && !ignore_obstalce)
			{
				obstacle_is_found = true;
				refer_path[i].executable = false;
			}
		}

		if(i+1 < (int)refer_path.size())
		{
			Odo next_motion = absol_odo_from_origin.getMotion(refer_path[i+1].absol_odo_from_origin); 

			bool is_start_or_end = refer_path[i].is_begin || refer_path[i+1].is_end;

			if(next_motion.getDist() < 100 && abs(next_motion.th) > 10 && is_start_or_end)
				start_corner = true;
			else
				start_corner = false;
			
			if(start_corner)
				corners.push_back(i);
		}
	}

	if(ignore_obstalce)
		printf("ignore_obstalce\n");

	if(corners.size() < 2) corners.clear();

	if(draw)
	{
		cv::circle(planning_draw, cv::Point(grid_info.robot_col, grid_info.robot_row), param.real_circle_distance*grid_info.mm2pixel, 
			cv::Scalar(0, 0, 255));

		for(int i=0; i<(int)refer_path.size(); i++)
		{
			cv::Scalar color(0, 255, 0);
			if(!refer_path[i].executable) color = cv::Scalar(0, 0, 255);

			drawRobot(planning_draw, 
				refer_path[i].grid_odo_from_robot.x, 
				refer_path[i].grid_odo_from_robot.y, 
				refer_path[i].grid_odo_from_robot.th, 
				color, 15);
			
			if(i >= closest_idx_in && i <= far_idx_in)
				cv::circle(planning_draw, 
					cv::Point2d(refer_path[i].grid_odo_from_robot.x, 
								refer_path[i].grid_odo_from_robot.y), 
					5, cv::Scalar(0, 0, 255), 2);

			if(i >= closest_idx_in && i <= longest_idx)
				cv::circle(planning_draw, 
					cv::Point2d(refer_path[i].grid_odo_from_robot.x, 
								refer_path[i].grid_odo_from_robot.y), 
					5, cv::Scalar(0, 0, 255), 1);
		}

		for(int i=0; i<(int)corners.size(); i++)
		{
			int idx = corners[i];
			cv::circle(planning_draw, 
				cv::Point((int)refer_path[idx].grid_odo_from_robot.x, (int)refer_path[idx].grid_odo_from_robot.y), 
				15, cv::Scalar(125, 125, 0), -1);
		}
	}	

	if(far_idx_in == -1) far_idx_in = closest_idx_in;
	if(longest_idx == -1) longest_idx = closest_idx_in;

	//if(obstacle_is_found && param.detour>0.0f)
	//{
	//	if(!detourPath.empty()) message.push_back("Use detourPath");	
	//	else message.push_back("Make detourPath");	
	//	return false;
	//}
	

	if (closest_idx_in == -1 && closest_idx_out == -1)
    {
        message.push_back("could not find any path");

		navi_status.status = Msg::cona_navistatus::ERROR;
		strcpy(navi_status.log, std::string("there is no path").c_str());
        return false;
    }
	else if(closest_idx_in == -1)
	{
        message.push_back("No visible refer path. Make virtual target");
		Odo& target = refer_path[closest_idx_out].grid_odo_from_robot;  

		double margin = 10.0;	
		double x = std::min(std::max(target.x, margin), grid.cols - margin);
		double y = std::min(std::max(target.y, margin), grid.rows - margin);

		double col_rate = (x - (double)grid_info.robot_col) / (target.x - (double)grid_info.robot_col);
		double row_rate = (y - (double)grid_info.robot_row) / (target.y - (double)grid_info.robot_row);
		double rate = std::min(col_rate, row_rate);
	
		Odo gap_odo = grid_start.getMotion(target);
		gap_odo.x *= rate;	
		gap_odo.y *= rate;	

		Odo new_target = grid_start.addMotion(gap_odo);
		grid_goal.x = new_target.x;
		grid_goal.y = new_target.y;
		grid_goal.th = new_target.th;
		goal_idx_in_refer = -1;

		navi_status.status = Msg::cona_navistatus::LOST;
		strcpy(navi_status.log, std::string("No visible refer path").c_str());
		return false;
	}

	bool found_corner = false;
	for (int i = closest_idx_in; i < (int)refer_path.size(); i++)
	{
		if(refer_path[i].absol_odo_from_robot.getDist() > param.real_circle_distance) break;

		bool temp_found_corner = false;
		for(int j=0; j<(int)corners.size(); j++)
		{
			if(i == corners[j])
			{
				temp_found_corner = true;
			}
		}

		if(found_corner == true && temp_found_corner == false)
		{
			far_idx_in = i;
			break;
		}

		found_corner = temp_found_corner;
		
		if(found_corner) break;
	}

	Odo dist_far2last = refer_path[far_idx_in].absol_odo_from_robot.getMotion(refer_path.back().absol_odo_from_robot);
	bool last_path_is_the_target = false;
	if(dist_far2last.getDist() < 100.0) last_path_is_the_target = true;

//	bool angle_mode = (far_idx_in == (int)refer_path.size() -1) || found_corner;
	bool angle_mode = last_path_is_the_target || found_corner;

	int temp_goal_idx = -1;

	if(angle_mode)
	{
		if(far_idx_in < closest_idx_in)
		{
			printf("far_idx_in idx error %d\n", far_idx_in);
			far_idx_in = closest_idx_in+1;
			if(far_idx_in>=refer_path.size())
				far_idx_in = (int)refer_path.size()-1;
		}

		message.push_back("angle_mode");
		temp_goal_idx = far_idx_in;
		for(int i=far_idx_in; i>= closest_idx_in; i--)
		{
			Odo& gap = refer_path[i].absol_odo_from_robot;
			if(gap.getDist() < param.real_circle_distance
				&& abs(gap.th) < param.angleGap)
					break;
			
			temp_goal_idx = i;
		}
	}
	else
	{
		message.push_back("normal_mode");
		float grid_path_mergin = param.real_path_following_mergin * grid_info.mm2pixel;
		float bx = (float)grid_info.robot_col;
		float by = (float)grid_info.robot_row;
	
//		for (int i = closest_idx_in; i <= far_idx_in; i++)
		for (int i = closest_idx_in; i <= longest_idx; i++)
		{

			float tx = (float)refer_path[i].grid_odo_from_robot.x;
			float ty = (float)refer_path[i].grid_odo_from_robot.y;
			float t_th = (float)refer_path[i].grid_odo_from_robot.th;

			float a = ty - by;
			float b = -(tx - bx);
			float c = -bx*ty + tx*by;
			float ab = sqrt(a*a + b*b);	

			bool found_corner = false;
//			for(int j=0; j<(int)corners.size(); j++)
//			{
//				if(i == corners[j]) found_corner = true;
//				if(found_corner) break;
//			}

			bool clear = true;	
			for(int j=closest_idx_in; j<=i; j++)
			{
				float nx = (float)refer_path[j].grid_odo_from_robot.x;
				float ny = (float)refer_path[j].grid_odo_from_robot.y;
				float d = abs(a*nx + b*ny + c) / ab;

				double angle_ratio = std::max(std::min(1.0 - abs(refer_path[j].absol_odo_from_robot.th)/20.0, 1.0), 0.2);
				if(refer_path[j].absol_odo_from_robot.getDist() <= param.real_circle_distance) angle_ratio = 1.0;

				float mergin = (float)(angle_ratio * grid_path_mergin);
				if(d > mergin)
				{
					clear = false;
					break;
				}

				if(draw)
				{
					cv::circle(planning_draw, 
						cv::Point((int)refer_path[j].grid_odo_from_robot.x, (int)refer_path[j].grid_odo_from_robot.y), 
						mergin, cv::Scalar(255, 0, 0), 1);
//					cv::circle(planning_draw, 
//						cv::Point((int)refer_path[j].grid_odo_from_robot.x, (int)refer_path[j].grid_odo_from_robot.y), 
//						d, cv::Scalar(255, 255, 0), 3);
				}
			}
	
			if((t_th < -param.angleGap || t_th > param.angleGap) && 
					refer_path[i].absol_odo_from_robot.getDist() > param.real_circle_distance) clear = false;

			temp_goal_idx = i;	
			if(!clear) 
			{
				if(i == closest_idx_in) temp_goal_idx = far_idx_in;
				break;
			}


			if(found_corner) break;
		}

	}

	if (temp_goal_idx == -1)
	{
		message.push_back("Error. No temp_goal_idx");

		navi_status.status = Msg::cona_navistatus::ERROR;
		strcpy(navi_status.log, std::string("cannot determine a subgoal").c_str());

		return false;
	}

	float clearance = getLocalPathClearance((float)grid_info.robot_col, (float)grid_info.robot_row, 0.0f,
			(float)refer_path[temp_goal_idx].grid_odo_from_robot.x, 
			(float)refer_path[temp_goal_idx].grid_odo_from_robot.y, 
			(float)refer_path[temp_goal_idx].grid_odo_from_robot.th);

	bool find_target_in_refer = true;
	if (clearance < (float)param.min_clearance && !ignore_obstalce)
	{
		bool found_detour_path = false;
		if(param.detour>0.0f) 
		{
			find_target_in_refer = false;

			int detour_path_goal = temp_goal_idx;
			for(detour_path_goal; detour_path_goal<(int)refer_path.size(); detour_path_goal++)
				if(refer_path[detour_path_goal].executable) break;

			if(detour_path_goal < (int)refer_path.size())
			{
				found_detour_path = true;

				grid_mtx.lock();
				crt.input.binary_grid = grid.clone();
				grid_mtx.unlock();
				crt.input.mm2pixel = grid_info.mm2pixel;
				crt.input.start_x = grid_info.robot_col;
				crt.input.start_y = grid_info.robot_row;
				crt.input.start_th = 0.0f;
				crt.input.goal_x = (float)refer_path[detour_path_goal].grid_odo_from_robot.x;
				crt.input.goal_y = (float)refer_path[detour_path_goal].grid_odo_from_robot.y;
				crt.input.goal_th = (float)refer_path[detour_path_goal].grid_odo_from_robot.th;
				crt.input.draw = false;

				if(!crt.planning())
					logger.push_back(Logger::Error, crt.output.error_log);	

				detourPath.clear();
				Odo grid_robot(crt.input.start_x, crt.input.start_y, 0.0);
				double r2d = 180.0/CV_PI;

				nowRobot_mtx.lock();
				Odo now_robotodo(nowRobot.x, nowRobot.y, nowRobot.th);
				nowRobot_mtx.unlock();

				for(int i=0; i<crt.output.path.cols; i++)
				{
					detourPath.push_back(ReferPath_Info());
					ReferPath_Info& target = detourPath.back();

					target.grid_odo_from_robot.x = crt.output.path.at<float>(0, i);
					target.grid_odo_from_robot.y = crt.output.path.at<float>(1, i);
					target.grid_odo_from_robot.th = crt.output.path.at<float>(2, i)*r2d;

					target.absol_odo_from_robot.x = 
						(grid_info.robot_row-crt.output.path.at<float>(1, i))/grid_info.mm2pixel;
					target.absol_odo_from_robot.y = 
						(grid_info.robot_col-crt.output.path.at<float>(0, i))/grid_info.mm2pixel;
					target.absol_odo_from_robot.th = target.grid_odo_from_robot.th;
			
					Odo absol_odo = now_robotodo.addMotion(target.absol_odo_from_robot);
					target.absol_odo_from_origin.x = absol_odo.x;
					target.absol_odo_from_origin.y = absol_odo.y;
					target.absol_odo_from_origin.th = absol_odo.th;

					target.executable = false;
				}

				message.push_back(cv::format("found %d detour path node",crt.output.path.cols));
				return 0;
			}
		}

		if(!found_detour_path)
		{
			bool found_closeser_target = false;
			int found_closeser_target_idx = -1;

			for(int i=temp_goal_idx; i>=closest_idx_in; i--)
			{
				clearance = getLocalPathClearance((float)grid_start.x, (float)grid_start.y, (float)grid_start.th,
				(float)refer_path[i].grid_odo_from_robot.x, 
				(float)refer_path[i].grid_odo_from_robot.y, 
				(float)refer_path[i].grid_odo_from_robot.th);

				if(clearance > (float)param.min_clearance && refer_path[i].absol_odo_from_robot.getDist() > 500.0 )	
				{
					found_closeser_target_idx = i;
					found_closeser_target = true;
					break;
				}
			}

			if(found_closeser_target)
			{
				grid_goal.x = refer_path[found_closeser_target_idx].grid_odo_from_robot.x;
				grid_goal.y = refer_path[found_closeser_target_idx].grid_odo_from_robot.y;
				grid_goal.th = refer_path[found_closeser_target_idx].grid_odo_from_robot.th;
				temp_goal_idx = found_closeser_target_idx;
				message.push_back("found_closeset target.");
				goal_idx_in_refer = found_closeser_target_idx;
			}
			else
			{
				message.push_back("Cannot find executable refer path.");

				grid_goal.x = grid_start.x;
				grid_goal.y = grid_start.y;
				grid_goal.th = grid_start.th;

				navi_status.status = Msg::cona_navistatus::OBSTACLE_STOP;
				strcpy(navi_status.log, std::string("OBSTACLE_STOP").c_str());

				return false;
			}
		}
	}
	else
	{
		grid_goal.x = refer_path[temp_goal_idx].grid_odo_from_robot.x;
		grid_goal.y = refer_path[temp_goal_idx].grid_odo_from_robot.y;
		grid_goal.th = refer_path[temp_goal_idx].grid_odo_from_robot.th;
		goal_idx_in_refer = temp_goal_idx;
	}

	cv::Point2f output_p(refer_path[temp_goal_idx].grid_odo_from_robot.x, refer_path[temp_goal_idx].grid_odo_from_robot.y);

	if(1)
	{
		if(0 < temp_goal_idx && temp_goal_idx < (int)refer_path.size()-1)
		{
			if(refer_path[temp_goal_idx].absol_odo_from_robot.getDist() > param.real_circle_distance)
			{
				cv::Point2f p1(refer_path[temp_goal_idx].grid_odo_from_robot.x, refer_path[temp_goal_idx].grid_odo_from_robot.y);
				cv::Point2f p2(refer_path[temp_goal_idx-1].grid_odo_from_robot.x, refer_path[temp_goal_idx-1].grid_odo_from_robot.y);

				float step = 20.0;
				float dx = (p1.x-p2.x) / step;
				float dy = (p1.y-p2.y) / step;
				float max_dist = param.real_circle_distance * grid_info.mm2pixel;
				for(int i=0; i<(int)step; i++)
				{
					cv::Point2f p3(p2.x+((float)i*dx), p2.y+((float)i*dy));
					float dist_x = p3.x - grid_info.robot_col;
					float dist_y = p3.y - grid_info.robot_row;
					float dist = std::sqrt(dist_x*dist_x + dist_y*dist_y);
					if(dist > max_dist)
					{
						output_p = p3;
						break;
					}
				}
			}

			if(fabs(refer_path[temp_goal_idx].absol_odo_from_robot.th) > param.angleGap)
			{
				cv::Point2f p1(refer_path[temp_goal_idx].grid_odo_from_robot.x, refer_path[temp_goal_idx].grid_odo_from_robot.y);
				cv::Point2f p2(refer_path[temp_goal_idx-1].grid_odo_from_robot.x, refer_path[temp_goal_idx-1].grid_odo_from_robot.y);
				double angle_gap = refer_path[temp_goal_idx].grid_odo_from_robot.th - refer_path[temp_goal_idx-1].grid_odo_from_robot.th;

				float step = 20.0;
				float dx = (p1.x-p2.x) / step;
				float dy = (p1.y-p2.y) / step;
				float dth = (float)angle_gap / step;
				for(int i=0; i<(int)step; i++)
				{
					cv::Point2f p3(p2.x+((float)i*dx), p2.y+((float)i*dy));
					float now_angle = (float)refer_path[temp_goal_idx-1].grid_odo_from_robot.th + (float)i*dth;

					if(now_angle > param.angleGap || now_angle < -param.angleGap)
					{
						output_p = p3;

						printf("angle inter: %lf %f %lf\n", 
							refer_path[temp_goal_idx-1].grid_odo_from_robot.th,
							now_angle,
							refer_path[temp_goal_idx].grid_odo_from_robot.th);

						break;
					}
				}

			}
		}
	}

	grid_goal.x = output_p.x;
	grid_goal.y = output_p.y;

	if(draw)
	{
		cv::line(planning_draw, cv::Point2f(grid_start.x, grid_start.y), cv::Point2f(grid_goal.x, grid_goal.y), 
			cv::Scalar(255, 0, 0), 2);
		
		drawRobot(planning_draw, grid_goal.x, grid_goal.y, grid_goal.th, cv::Scalar(255, 0, 0), 50);
	}	

	return true;
}

bool Robot::gen_vel_with_detourPath(std::vector<ReferPath_Info>& refer_path)
{
	if(refer_path.size() == 0)
	{
		printf("there is no detour_path\n");
		return false;
	}

	bool detour_clear = false;
	bool draw = !planning_draw.empty(); 

	navi_status.status = Msg::cona_navistatus::OBSTACLE_AVOID;
	strcpy(navi_status.log, std::string("OBSTACLE_AVOID is not implemented").c_str());

	referPath_update(refer_path);	

	int goal_idx = refer_path.size()-1;
	for(int i = refer_path.size()-1; i>=0; i--)
	{
		float clearance = getLocalPathClearance((float)grid_info.robot_col, (float)grid_info.robot_row, 0.0f,
				(float)refer_path[i].grid_odo_from_robot.x, 
				(float)refer_path[i].grid_odo_from_robot.y, 
				(float)refer_path[i].grid_odo_from_robot.th);

		goal_idx = i;
		if(clearance > (float)param.min_clearance*1.1f) 
		{
			float clearance = getLocalPathClearance((float)grid_info.robot_col, (float)grid_info.robot_row, 0.0f,
					(float)refer_path[i].grid_odo_from_robot.x, 
					(float)refer_path[i].grid_odo_from_robot.y, 
					(float)refer_path[i].grid_odo_from_robot.th, true);
			break;
		}
	}

	if(goal_idx < 0 || goal_idx >= (int)refer_path.size())
	{
		logger.push_back(Logger::Error, cv::format("error in gen_vel_with_detourpath. goal idx: %d", goal_idx));
		return false;
	}

	if(goal_idx == refer_path.size()-1)
	{
		detour_clear = true;
		logger.push_back(Logger::Info, "done detour");

		grid_goal.x = refer_path[goal_idx].grid_odo_from_robot.x;
		grid_goal.y = refer_path[goal_idx].grid_odo_from_robot.y;
		grid_goal.th = refer_path[goal_idx].grid_odo_from_robot.th;
//		return true;

//		referPath_mtx.lock();	
//		std::vector<ReferPath_Info> now_referPath = referPath;
//		referPath_mtx.unlock();	
//		gen_vel_with_referPath(now_referPath);
	}
	else
	{
		if(goal_idx < 0)
		{
			message.push_back("detour fail");
			detour_clear = true;

			grid_goal.x = grid_info.robot_col; 
			grid_goal.y = grid_info.robot_row;
			grid_goal.th = 0;
		}
		else
		{
			grid_goal.x = refer_path[goal_idx].grid_odo_from_robot.x;
			grid_goal.y = refer_path[goal_idx].grid_odo_from_robot.y;
			grid_goal.th = refer_path[goal_idx].grid_odo_from_robot.th;
		}
	}

	if(draw)
	{
		for(int i=0; i<(int)refer_path.size(); i++)
		{
			cv::Scalar color(0, 255, 0);
			if(!refer_path[i].executable) color = cv::Scalar(0, 0, 255);

			if(i!=0)
				cv::line(planning_draw, 
					cv::Point2f(refer_path[i].grid_odo_from_robot.x, refer_path[i].grid_odo_from_robot.y),
					cv::Point2f(refer_path[i-1].grid_odo_from_robot.x, refer_path[i-1].grid_odo_from_robot.y),
					cv::Scalar(0, 255, 0), 2);

			drawRobot(planning_draw, 
				refer_path[i].grid_odo_from_robot.x, 
				refer_path[i].grid_odo_from_robot.y, 
				refer_path[i].grid_odo_from_robot.th, 
				color, 15);

//			printf("%lf %lf %lf\n", 
//				refer_path[i].grid_odo_from_robot.x, 
//				refer_path[i].grid_odo_from_robot.y, 
//				refer_path[i].grid_odo_from_robot.th);
		}	
		
		cv::line(planning_draw, cv::Point2f(grid_start.x, grid_start.y), cv::Point2f(grid_goal.x, grid_goal.y), 
			cv::Scalar(255, 0, 0), 2);
		
		drawRobot(planning_draw, grid_goal.x, grid_goal.y, grid_goal.th, cv::Scalar(255, 0, 0), 50);
	}

	if(detour_clear) detourPath.clear();

	return true;
}

bool Robot::gen_vel(std::vector<ReferPath_Info>& refer_path)
{
	Msg::Planning msg;
	memset(&msg, 0, sizeof(Msg::Planning));

    double MAX_TRAN_VEL = param.max_tran_vel;
    double MAX_ROT_VEL = param.max_rot_vel;

    double vel_rate_variance = 10; 

    float x = (float)grid_start.x - (float)grid_goal.x;
    float y = (float)grid_start.y - (float)grid_goal.y;

	float start_dist = -1.0;
	for(int i=0; i<(int)refer_path.size(); i++)
		if(refer_path[i].is_begin)
			start_dist = refer_path[i].absol_odo_from_robot.getDist();

    float goal_dist_real = std::sqrt(x*x + y*y) / grid_info.mm2pixel;

	bool ignore_y = false;
	bool target_is_the_goal = false;
	if(goal_idx_in_refer >= 0 && goal_idx_in_refer < (int)refer_path.size()) 
		if(refer_path[goal_idx_in_refer].is_end)
		{
			if(goal_dist_real < param.real_circle_distance)
			{
				msg.goal_idx = refer_path[goal_idx_in_refer].idx;
				target_is_the_goal = true;
				message.push_back("target_is the goal");

				if(param.ignore_y_error)
					for(int ignore_i = 0; ignore_i<(int)param.ignore_y_error_list.size(); ignore_i++)
						if(refer_path[goal_idx_in_refer].idx == param.ignore_y_error_list[ignore_i])
						{
							ignore_y = true;
							x = 0.0f;	
    						goal_dist_real = std::sqrt(x*x + y*y) / grid_info.mm2pixel;
							printf("ignore_y_error\n");
						}
			}

			if(goal_dist_real < 2.0*param.real_circle_distance)
				target_is_the_goal = true;
		}

	float goal_dist_rate = 1.0f;
	if(target_is_the_goal) goal_dist_rate = goal_dist_real / (2.0*param.real_circle_distance);
	else goal_dist_rate = goal_dist_real / (2.0*param.real_circle_distance);

	if(goal_dist_rate > 1.0f) goal_dist_rate = 1.0f;

	float start_dist_rate = 1.0f;
	if(0)
	{
		if(start_dist > 0.0f) start_dist_rate = start_dist / 1000.0f;
		if(start_dist_rate < 0.2f) start_dist_rate = 0.2f;
		if(start_dist_rate > 1.0f) start_dist_rate = 1.0f;
		if(start_dist_rate != 1.0f) printf("slow start with rate: %f\n", start_dist_rate);
	}

	float dist_vel_rate = std::min(goal_dist_rate, start_dist_rate);

	float x_dist_to_goal = y / grid_info.mm2pixel;

	message.push_back(cv::format("goal_dist %f", goal_dist_real));

	float target_angle = 0.0f;
    if (x == 0 && y == 0)
	{
		following_mode = 0;
		dist_vel_rate = 0.0f;
		target_angle = 0.0f;
	}
//	else if(goal_dist_real < 150.0f && following_mode == 1) 
	else if(goal_dist_real < 1000.0f && following_mode == 1 && target_is_the_goal) 
	{
		target_angle = 0;
		if(x_dist_to_goal < 0) 
		{
			dist_vel_rate = -dist_vel_rate;
			message.push_back(cv::format("t_positioning back, %f", x_dist_to_goal));
		}
		else
		{
			message.push_back(cv::format("t_positioning, %f", x_dist_to_goal));
		}

		if(target_is_the_goal)
		{
			navi_status.status = Msg::cona_navistatus::APPROACH_GOAL;
			strcpy(navi_status.log, cv::format("APPROACH_GOAL %d", msg.goal_idx).c_str());
		}

		if(x_dist_to_goal < 30.0f && x_dist_to_goal > -30.0f)
			following_mode = 2;
	}
	//else if(goal_dist_real < 200.0f && following_mode == 2) 
	else if(goal_dist_real < 1200.0f && following_mode == 2 && target_is_the_goal) 
	{
		target_angle = grid_goal.th;
		dist_vel_rate = 0.0f;
		message.push_back("r_positioning");

//		if(target_is_the_goal)
		if(1)
		{
			message.push_back("fine_positioning");
			output_precise = true;
		}

		float arrvied_angle = 30.0f;
		if((target_angle > -arrvied_angle) && (target_angle < arrvied_angle) && target_is_the_goal)
		{
			following_mode = 0;

			msg.arrived = true;
			m_ipc->publish<Msg::Planning>("Planning", msg);

			output_t_vel = 0.0;	
			output_r_vel = 0.0;	

			navi_status.status = Msg::cona_navistatus::ARRIVED_GOAL;
			strcpy(navi_status.log, cv::format("ARRIVED_GOAL %d", msg.goal_idx).c_str());
			return true;
		}
	}
//	else if(x_dist_to_goal < 0 && goal_dist_real < 100.0f)
//	{
//		message.push_back(cv::format("move back way x:%f gd:%f", x_dist_to_goal, goal_dist_real));
//		target_angle = 0.0; 
//		dist_vel_rate = -0.2f;
//	}
    else
	{
		target_angle = 180.0f / (float)CV_PI * atan2(x, y);
		following_mode = 1;
	}

	float now_target_angle = target_angle;
	float angle_gap = target_angle - prev_target_angle;
	target_angle = angle_gap/2.0f + prev_target_angle;
	prev_target_angle = target_angle;

	double vel_rate = exp(-target_angle*target_angle / 2.0 / vel_rate_variance / vel_rate_variance);

	double rotvel = std::min(std::abs((double)target_angle), MAX_ROT_VEL);

	if (target_angle < 0) rotvel = -rotvel;

	output_t_vel = vel_rate * dist_vel_rate * MAX_TRAN_VEL;
	output_r_vel = rotvel;

	if(output_t_vel==0.0 && now_target_angle == 0.0) output_r_vel = 0.0;

	return true;
}

void Robot::run_planning(void)
{
	Time obstacle_stop_time;
	int obstacle_counter = 0;
	Rate rate(30);
	while(1)
	{
		if(m_ipc->get_pub_num("Grid") <= 0)
			if(grid.empty())
				grid = cv::Mat(500, 500, CV_8UC1, cv::Scalar(125));

		if(grid.empty())
		{ 
			rate.sleep();
			continue;
		}

		grid_mtx.lock();
		cv::distanceTransform(grid, distance_grid, CV_DIST_L2, 3);
		if(!plot[0].first.empty()) 
			cv::cvtColor(grid, planning_draw, CV_GRAY2RGB);
		else planning_draw = cv::Mat();
		grid_mtx.unlock();

		grid_start.x = grid_info.robot_col;
		grid_start.y = grid_info.robot_row;
		grid_start.th = 0.0;
		grid_goal.x = grid_start.x;
		grid_goal.y = grid_start.y;
		grid_goal.th = grid_start.th;
		goal_idx_in_refer = 0;

		output_t_vel = 0.0f;
		output_r_vel = 0.0f;
		output_precise = false;

		memset(&navi_status, 0, sizeof(Msg::cona_navistatus));	
		bool pub_navi_status = false;
		double t_rate = 1.0;
		if(referPath.size() != 0)
		{
			navi_status.status = Msg::cona_navistatus::MOVE;
			strcpy(navi_status.log, cv::format("MOVE").c_str());

			referPath_mtx.lock();	
			std::vector<ReferPath_Info> now_referPath = referPath;
			referPath_mtx.unlock();	

			if(param.detour <= 0.0f)
			{
				double obstacle_dist = 4000.0;
				bool execute_refer = gen_vel_with_referPath2(now_referPath, obstacle_dist);
				t_rate = std::min(1.0, obstacle_dist/4000.0);

				if(!execute_refer) obstacle_stop_time.set_now();

				Time now_time;
				now_time.set_now();
				double time_gap = now_time - obstacle_stop_time;
				if(time_gap<2.0) t_rate = 0.0; 

				gen_vel(now_referPath);
			}
			else
			{
				bool execute_refer = false;
				if(detourPath.empty())
					execute_refer= gen_vel_with_referPath(now_referPath);

				if(!execute_refer) obstacle_counter++;
				else obstacle_counter = 0;

				bool execute_detour = false;
				if(obstacle_counter>5 && !detourPath.empty())
				{
					execute_detour = gen_vel_with_detourPath(detourPath);
				}

				gen_vel(now_referPath);
			}

			message.push_back(cv::format("target_t:%lf target_r:%lf", output_t_vel, output_r_vel));
			pub_navi_status = true;
		}
		else
		{
			prev_target_angle = 0.0f;
			following_mode = 0;
			detourPath.clear();
		}

		if(joy_vel) ss.move(output_t_vel_joy, output_r_vel_joy, output_precise_joy);
//		else if(TEST_MODE)
//		{		
//			ss.move(0.0f, 0.0f);
//		}
		else 
		{
			if(navi_vel_rate == 0.0 && referPath.size() != 0)
			{
				memset(navi_status.log, 0, sizeof(char)*256);
				if(lost_flag)
				{
					navi_status.status = Msg::cona_navistatus::LOST;
					strcpy(navi_status.log, cv::format("LOST!!. deadrecording dist: %lf", deadrecording).c_str());
				}
				else
				{
					navi_status.status = Msg::cona_navistatus::PAUSED_BY_USER;
					strcpy(navi_status.log, cv::format("PAUSED").c_str());
				}
			}

			ss.move(navi_vel_rate*output_t_vel, navi_vel_rate*output_r_vel, output_precise, t_rate);
		}

		if(pub_navi_status)
		{
			navi_status.total_distance = path_length;
			navi_status.remain_distance = remain_length;
			m_ipc->publish<Msg::cona_navistatus>("cona_navistatus", navi_status);
		}

		if(!plot[0].first.empty() && !planning_draw.empty())
		{
			for(int i=0; i<(int)message.size(); i++)
				cv::putText(planning_draw, message[i], cv::Point(15, 25*(i+1)), 0, 0.8, cv::Scalar(0, 255, 0), 2);
			
			float s_c = grid_info.robot_col - grid_info.mm2pixel*param.robot_size_start_y;
			float e_c = grid_info.robot_col - grid_info.mm2pixel*param.robot_size_end_y;
			float s_r = grid_info.robot_row - grid_info.mm2pixel*param.robot_size_start_x;
			float e_r = grid_info.robot_row - grid_info.mm2pixel*param.robot_size_end_x;
			cv::line(planning_draw, cv::Point2f(s_c, s_r), cv::Point2f(s_c, e_r), cv::Scalar(0, 0, 255));
			cv::line(planning_draw, cv::Point2f(s_c, e_r), cv::Point2f(e_c, e_r), cv::Scalar(0, 0, 255));
			cv::line(planning_draw, cv::Point2f(e_c, e_r), cv::Point2f(e_c, s_r), cv::Scalar(0, 0, 255));
			cv::line(planning_draw, cv::Point2f(e_c, s_r), cv::Point2f(s_c, s_r), cv::Scalar(0, 0, 255));

			cv::line(planning_draw, cv::Point(0, grid_info.robot_row), cv::Point(planning_draw.cols, grid_info.robot_row), 
				cv::Scalar(0, 0, 255));
			cv::line(planning_draw, cv::Point(grid_info.robot_col, 0), cv::Point(grid_info.robot_col, planning_draw.rows), 
				cv::Scalar(0, 0, 255));

			float arrow_size = 45.0f;
			cv::Point2f steering_center(50.0f, (float)planning_draw.rows-50.0f);
			cv::Point2f st_start(
				steering_center.x-arrow_size*sin(ss.steering_angle_r_now), 
				steering_center.y-arrow_size*cos(ss.steering_angle_r_now));

			cv::Point2f st_end(
				steering_center.x+arrow_size*sin(ss.steering_angle_r_now), 
				steering_center.y+arrow_size*cos(ss.steering_angle_r_now));

			cv::arrowedLine(planning_draw, st_end, st_start, cv::Scalar(0, 0, 0), 2);
			
			plot[0].second->lock();
			plot[0].first = planning_draw.clone();
			plot[0].second->unlock();
		}

		message.clear();

		rate.sleep();
	}
}

void Robot::drawRobot(cv::Mat &output, double x, double y, double th, cv::Scalar color, double size)
{
    double point1[3] = { size / 2.0, 0, 1 };
    double point2[3] = { -size / 2.0, 0, 1 };
    double point3[3] = { 0, size * 2.0 / 3.0, 1 };

    cv::Mat point1_mat(3, 1, CV_64FC1, point1);
    cv::Mat point2_mat(3, 1, CV_64FC1, point2);
    cv::Mat point3_mat(3, 1, CV_64FC1, point3);

    cv::Mat rotation_mat = cv::getRotationMatrix2D(cv::Point2f(0, 0), th, 1);

    cv::Mat rotated_point1 = rotation_mat * point1_mat;
    cv::Mat rotated_point2 = rotation_mat * point2_mat;
    cv::Mat rotated_point3 = rotation_mat * point3_mat;

    cv::Point p1(x - rotated_point1.at<double>(0, 0), y - rotated_point1.at<double>(1, 0));
    cv::Point p2(x - rotated_point2.at<double>(0, 0), y - rotated_point2.at<double>(1, 0));
    cv::Point p3(x - rotated_point3.at<double>(0, 0), y - rotated_point3.at<double>(1, 0));

    cv::line(output, p1, p2, color, 1);
    cv::line(output, cv::Point(x, y), p3, color, 1);
}

void Robot::odo_callback(Msg::Odometer* msg)
{
	nowRobot_mtx.lock();
	nowRobot_data_time = msg->data_time;
	nowRobot.x = msg->x;
	nowRobot.y = msg->y;
	nowRobot.th = msg->th;
	nowRobot_mtx.unlock();
//	printf("hanc: %lf %lf %lf\n", msg->x, msg->y, msg->th);
}

void Robot::joy_callback(Msg::Joy* msg)
{
	if(msg->button_lb) 
	{
		output_precise_joy = !output_precise_joy;
		printf("precise_mode: %d\n", (int)output_precise_joy);
	}

	if(!msg->button_lt)
	{
		joy_vel = false; 
		return;
	}

	joy_vel = true; 
	output_t_vel_joy = (double)msg->left_stick_y * param.joy_max_t_vel;
	output_r_vel_joy = (double)msg->left_stick_x * param.joy_max_r_vel;
	if(output_t_vel_joy < 0) output_r_vel_joy = -output_r_vel_joy;
}

void Robot::grid_callback(Msg::Grid* msg)
{
	grid_info.col = msg->col;
	grid_info.row = msg->row;
	grid_info.robot_col = msg->robot_col;
	grid_info.robot_row = msg->robot_row;
	grid_info.mm2pixel = msg->mm2pixel;

	if(!TEST_MODE)
	{	
		cv::Mat temp_grid(msg->row, msg->col, CV_8UC1, msg->gridData);
		grid_mtx.lock();
		grid = 	temp_grid.clone();
		grid_mtx.unlock();
	}
}

void Robot::navi_callback(Msg::Navigation* msg)
{
	navi_vel_rate = (double)msg->vel_rate;
	path_length = msg->path_length;
	remain_length = msg->remain_length;
	deadrecording = msg->deadrecording;
	lost_flag = msg->lost_flag;

	nowRobot_mtx.lock();
	Odo now_robotodo(nowRobot.x, nowRobot.y, nowRobot.th);
	nowRobot_mtx.unlock();

	referPath_mtx.lock();
	referPath.clear();
	for(int i=0; i<msg->path_size; i++)
	{
		Odo path_from_origin(msg->path_list[i][0], msg->path_list[i][1], msg->path_list[i][2]);

		bool path_begin = msg->path_list[i][3] == msg->path_start_idx;	
		bool path_ending = msg->path_list[i][3] == msg->path_end_idx;

		referPath.push_back(ReferPath_Info(path_from_origin, msg->path_list[i][3], path_begin, path_ending));
	}
	
	referPath_mtx.unlock();
}

void Robot::robot_input_callback(Msg::Robot_input* msg)
{
	if(msg->get_flag(Msg::Mode::draw1_on))
		plot[0].first = cv::Mat(500, 500 ,CV_8UC3, cv::Scalar(255, 255, 255));
	else if(msg->get_flag(Msg::Mode::draw1_off))
		plot[0].first = cv::Mat();
}









